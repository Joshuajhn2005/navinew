/* =================================================================
   SHAPED CORRIDOR SVG BUILDER
================================================================= */
function buildCorridorSvg(el) {
  const w = el.w, h = el.h;
  const color = el.color || '#e8f4fd';
  const stroke = 'none';
  const sw = 0;
  const ns = 'http://www.w3.org/2000/svg';

  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
  svg.setAttribute('preserveAspectRatio', 'none');
  svg.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;overflow:visible;';

  // arm thickness helpers — always 1/3 of each axis
  const ax = w / 3;  // horizontal arm thickness
  const ay = h / 3;  // vertical arm thickness

  const poly = pts => {
    const el = document.createElementNS(ns, 'polygon');
    el.setAttribute('points', pts.map(p => p.join(',')).join(' '));
    return el;
  };
  const rect = (x, y, rw, rh) => {
    const el = document.createElementNS(ns, 'rect');
    el.setAttribute('x', x); el.setAttribute('y', y);
    el.setAttribute('width', rw); el.setAttribute('height', rh);
    return el;
  };
  const ellipse = () => {
    const el = document.createElementNS(ns, 'ellipse');
    el.setAttribute('cx', w / 2); el.setAttribute('cy', h / 2);
    el.setAttribute('rx', w / 2 - sw); el.setAttribute('ry', h / 2 - sw);
    return el;
  };

  let shape;
  const t = el.type;

  if (t === 'Corridor-Square' || t === 'Corridor-Rect') {
    // Solid rectangle / square
    shape = rect(sw, sw, w - sw * 2, h - sw * 2);

  } else if (t === 'Corridor-Circle') {
    shape = ellipse();

  } else if (t === 'Corridor-Triangle') {
    // Triangle: apex top-center
    shape = poly([[w / 2, sw], [w - sw, h - sw], [sw, h - sw]]);

  } else if (t === 'Corridor-L') {
    // L: vertical left bar + horizontal bottom bar
    // Left col full height, bottom row from left col to right
    const cw = ax, ch = ay;
    shape = poly([
      [sw, sw],
      [sw + cw, sw],
      [sw + cw, h - sw - ch],
      [w - sw, h - sw - ch],
      [w - sw, h - sw],
      [sw, h - sw],
    ]);

  } else if (t === 'Corridor-T') {
    // T: top horizontal bar + center vertical bar down
    const barH = ay;
    const colW = ax;
    const cx = w / 2;
    shape = poly([
      [sw, sw],
      [w - sw, sw],
      [w - sw, sw + barH],
      [cx + colW / 2, sw + barH],
      [cx + colW / 2, h - sw],
      [cx - colW / 2, h - sw],
      [cx - colW / 2, sw + barH],
      [sw, sw + barH],
    ]);

  } else if (t === 'Corridor-U') {
    // U: two vertical side bars + horizontal bottom bar
    const sideW = ax;
    const botH = ay;
    // Use path for the hollow inside
    const p = document.createElementNS(ns, 'path');
    const ix = sw + sideW;          // inner x start
    const iy = sw;                  // inner y start
    const iw = w - sw * 2 - sideW * 2; // inner width
    const ih = h - sw - botH - sw; // inner height
    p.setAttribute('d',
      `M${sw},${sw} L${w - sw},${sw} L${w - sw},${h - sw} L${sw},${h - sw} Z ` +
      `M${ix},${iy} L${ix},${iy + ih} L${ix + iw},${iy + ih} L${ix + iw},${iy} Z`
    );
    p.setAttribute('fill-rule', 'evenodd');
    p.setAttribute('fill', color);
    p.setAttribute('stroke', stroke);
    p.setAttribute('stroke-width', sw);
    p.setAttribute('stroke-linejoin', 'round');
    p.classList.add('corridor-shape');
    svg.appendChild(p);
    return svg;

  } else if (t === 'Corridor-H') {
    // H: two vertical bars + horizontal center crossbar
    const barW = ax;
    const crossH = ay;
    const cy = h / 2;
    shape = poly([
      // Left bar
      [sw, sw],
      [sw + barW, sw],
      [sw + barW, cy - crossH / 2],
      // Center crossbar top
      [w - sw - barW, cy - crossH / 2],
      [w - sw - barW, sw],
      [w - sw, sw],
      [w - sw, h - sw],
      [w - sw - barW, h - sw],
      [w - sw - barW, cy + crossH / 2],
      // Center crossbar bottom
      [sw + barW, cy + crossH / 2],
      [sw + barW, h - sw],
      [sw, h - sw],
    ]);

  } else if (t === 'Corridor-E') {
    // E: left vertical bar + 3 horizontal prongs (top, mid, bottom)
    const barW = ax;
    const prongH = h / 7;   // each prong thickness
    const prongL = w - sw;  // full width prongs
    const midProngL = w * 0.75; // middle prong slightly shorter
    shape = poly([
      // Left vertical bar top-left → down
      [sw, sw],
      // Top prong →
      [prongL, sw],
      [prongL, sw + prongH],
      [sw + barW, sw + prongH],
      // Gap down to mid prong
      [sw + barW, h / 2 - prongH / 2],
      // Mid prong → (shorter)
      [midProngL, h / 2 - prongH / 2],
      [midProngL, h / 2 + prongH / 2],
      [sw + barW, h / 2 + prongH / 2],
      // Gap down to bottom prong
      [sw + barW, h - sw - prongH],
      // Bottom prong →
      [prongL, h - sw - prongH],
      [prongL, h - sw],
      // Back along bottom of bar
      [sw, h - sw],
    ]);

  } else if (t === 'Corridor-Y') {
    // Y: center vertical stem + two diagonal arms up-left and up-right
    const stemW = ax * 0.7;
    const cx = w / 2;
    // Stem: from bottom center up to h*0.55
    // Two arms diverge from h*0.55 to top-left and top-right corners area
    const jY = h * 0.52; // junction Y
    const armW = ax * 0.65;
    shape = poly([
      // Bottom of stem left
      [cx - stemW / 2, h - sw],
      // Bottom of stem right
      [cx + stemW / 2, h - sw],
      // Stem right up to junction
      [cx + stemW / 2, jY],
      // Right arm outer (top-right)
      [w - sw, sw],
      [w - sw - armW * 1.1, sw],
      // Right arm inner back to junction
      [cx + stemW / 2, jY + armW * 0.5],
      // tiny flat at junction top
      [cx - stemW / 2, jY + armW * 0.5],
      // Left arm inner
      [sw + armW * 1.1, sw],
      // Left arm outer
      [sw, sw],
      // Left arm back to junction
      [cx - stemW / 2, jY],
    ]);

  } else if (t === 'Corridor-Cross') {
    // Plus / Cross
    const cx = w / 2, cy = h / 2;
    shape = poly([
      [cx - ax / 2, sw],
      [cx + ax / 2, sw],
      [cx + ax / 2, cy - ay / 2],
      [w - sw, cy - ay / 2],
      [w - sw, cy + ay / 2],
      [cx + ax / 2, cy + ay / 2],
      [cx + ax / 2, h - sw],
      [cx - ax / 2, h - sw],
      [cx - ax / 2, cy + ay / 2],
      [sw, cy + ay / 2],
      [sw, cy - ay / 2],
      [cx - ax / 2, cy - ay / 2],
    ]);

  } else if (t === 'Corridor-Courtyard') {
    // Courtyard: rectangle with hollow square in the middle
    const margin = Math.min(w, h) * 0.28;
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('d',
      `M${sw},${sw} L${w - sw},${sw} L${w - sw},${h - sw} L${sw},${h - sw} Z ` +
      `M${sw + margin},${sw + margin} L${sw + margin},${h - sw - margin} ` +
      `L${w - sw - margin},${h - sw - margin} L${w - sw - margin},${sw + margin} Z`
    );
    p.setAttribute('fill-rule', 'evenodd');
    p.setAttribute('fill', color);
    p.setAttribute('stroke', stroke);
    p.setAttribute('stroke-width', sw);
    p.setAttribute('stroke-linejoin', 'round');
    p.classList.add('corridor-shape');
    svg.appendChild(p);
    return svg;
  }

  if (shape) {
    shape.setAttribute('fill', color);
    shape.setAttribute('stroke', stroke);
    shape.setAttribute('stroke-width', sw);
    shape.setAttribute('stroke-linejoin', 'round');
    shape.classList.add('corridor-shape');
    svg.appendChild(shape);
  }
  return svg;
}

/* =================================================================
   RENDERING
================================================================= */
function renderAll() {
  renderStructure();
  renderCanvas();
  updatePropsPanel();
  renderStairLinksPanel();
  renderUniversalLinksPanel();
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

function renderStructure() {
  const list = document.getElementById('floorsList');
  list.innerHTML = '';
  state.buildings.forEach(bldg => {
    const bDiv = document.createElement('div');
    bDiv.className = 'item' + (bldg.id === state.currBuildingId ? ' current' : '');
    bDiv.innerHTML = `
      <div style="display:flex;align-items:center;width:100%;">
        <i data-lucide="building" style="width:14px;height:14px;opacity:0.8;margin-right:8px;"></i>
        <span style="flex:1;">${bldg.name}</span>
        <button class="icon-btn" style="background:transparent;border:none;color:var(--text-color);cursor:pointer;padding:2px;" onclick="renameBuilding(event, ${bldg.id})" title="Rename Building">
          <i data-lucide="edit-2" style="width:12px;height:12px;"></i>
        </button>
        <button class="icon-btn" style="background:transparent;border:none;color:var(--text-color);cursor:pointer;padding:2px;" onclick="deleteBuilding(event, ${bldg.id})" title="Delete Building">
          <i data-lucide="trash-2" style="width:12px;height:12px;color:#ef4444;"></i>
        </button>
      </div>
    `;
    bDiv.onclick = () => {
      state.currBuildingId = bldg.id;
      const bldgFloors = state.floors.filter(f => f.buildingId === bldg.id);
      if (bldgFloors.length > 0) {
        state.currFloorId = bldgFloors[0].id;
        state.currBlockId = bldgFloors[0].blocks[0].id;
      } else {
        state.currFloorId = null;
        state.currBlockId = null;
      }
      state.selectedId = null;
      renderAll();
    };
    list.appendChild(bDiv);

    if (bldg.id === state.currBuildingId) {
      const bldgFloors = state.floors.filter(f => f.buildingId === bldg.id);
      bldgFloors.forEach((f, floorIndex) => {
        const canMoveUp = floorIndex > 0;
        const canMoveDown = floorIndex < bldgFloors.length - 1;
        const moveUpDisabled = canMoveUp ? "" : "disabled";
        const moveDownDisabled = canMoveDown ? "" : "disabled";
        const fDiv = document.createElement('div');
        fDiv.className = 'item item-sub' + (f.id === state.currFloorId ? ' current' : '');
        fDiv.innerHTML = `
          <div style="display:flex;align-items:center;width:100%;">
            <i data-lucide="layers" style="width:14px;height:14px;opacity:0.8;margin-right:8px;"></i>
            <span style="flex:1;">${f.name}</span>
            <button class="icon-btn" style="background:transparent;border:none;color:var(--text-color);cursor:pointer;padding:2px;opacity:${canMoveUp ? 1 : 0.35};" onclick="moveFloor(event, ${f.id}, -1)" title="Move Floor Up" ${moveUpDisabled}>
              <i data-lucide="chevron-up" style="width:12px;height:12px;"></i>
            </button>
            <button class="icon-btn" style="background:transparent;border:none;color:var(--text-color);cursor:pointer;padding:2px;opacity:${canMoveDown ? 1 : 0.35};" onclick="moveFloor(event, ${f.id}, 1)" title="Move Floor Down" ${moveDownDisabled}>
              <i data-lucide="chevron-down" style="width:12px;height:12px;"></i>
            </button>
            <button class="icon-btn" style="background:transparent;border:none;color:var(--text-color);cursor:pointer;padding:2px;" onclick="renameFloor(event, ${f.id})" title="Rename Floor">
              <i data-lucide="edit-2" style="width:12px;height:12px;"></i>
            </button>
            <button class="icon-btn" style="background:transparent;border:none;color:var(--text-color);cursor:pointer;padding:2px;" onclick="deleteFloor(event, ${f.id})" title="Delete Floor">
              <i data-lucide="trash-2" style="width:12px;height:12px;color:#ef4444;"></i>
            </button>
          </div>
        `;
        fDiv.onclick = (e) => { e.stopPropagation(); state.currFloorId = f.id; state.currBlockId = f.blocks[0].id; state.selectedId = null; renderAll(); };
        list.appendChild(fDiv);

      });
    }
  });
}

function renderCanvas() {
  // Preserve the SVG arrow overlay
  const svg = document.getElementById('pathArrowSvg');
  const svgHtml = svg ? svg.outerHTML : '';
  canvas.innerHTML = svgHtml || '<svg id="pathArrowSvg" xmlns="http://www.w3.org/2000/svg"></svg>';
  // Re-add wall preview
  const preview = document.createElement('div');
  preview.id = 'wallDrawPreview';
  canvas.appendChild(preview);

  const fragment = document.createDocumentFragment();

  // Draw walls for current floor
  const floorWalls = state.walls.filter(w => w.floorId === state.currFloorId);
  floorWalls.forEach(wall => {
    const div = document.createElement('div');
    div.className = 'wall-element';
    if (wall.id === state.selectedWallId) div.classList.add('selected');
    div.id = 'wall-' + wall.id;
    const isHoriz = wall.w >= wall.h;
    // Ensure minimum thickness for visibility
    const displayW = isHoriz ? wall.w : Math.max(wall.w, 8);
    const displayH = isHoriz ? Math.max(wall.h, 8) : wall.h;
    div.style.cssText = `left:${wall.x}px;top:${wall.y}px;width:${displayW}px;height:${displayH}px;`;
    div.title = 'Wall — click to select, Del to delete';

    // Delete button (shown when selected)
    const delBtn = document.createElement('button');
    delBtn.className = 'wall-del-btn';
    delBtn.textContent = '✕';
    delBtn.title = 'Delete wall';
    delBtn.onmousedown = e => { e.stopPropagation(); };
    delBtn.onclick = e => { e.stopPropagation(); state.selectedWallId = wall.id; deleteSelectedWall(); };
    div.appendChild(delBtn);

    const faces = document.createElement('div');
    faces.className = 'faces';
    div.appendChild(faces);

    // Resize handle at far end
    const re = document.createElement('div');
    re.className = 'wall-resize-end';
    if (isHoriz) {
      re.style.cssText = 'right:-5px;top:50%;transform:translateY(-50%);cursor:ew-resize;';
    } else {
      re.style.cssText = 'bottom:-5px;left:50%;transform:translateX(-50%);cursor:ns-resize;';
    }
    re.onmousedown = e => startWallResize(e, wall, isHoriz ? 'h' : 'v');
    div.appendChild(re);

    div.onmousedown = e => {
      if (e.target === re || e.target === delBtn) return;
      e.stopPropagation();
      state.selectedId = null;
      state.selectedWallId = wall.id;
      if (state.is3D) {
        renderAll();
        return;
      }
      renderAll();
      startWallDrag(e, wall);
    };
    fragment.appendChild(div);
  });

  const currentFloor = curFloor();
  if (currentFloor) {
    currentFloor.blocks.forEach(block => {
      block.elements.forEach(el => {
        const div = document.createElement('div');
        div.className = 'element';
        if (el.id === state.selectedId) div.classList.add('selected');
        if (el.isStairs || el.type === 'Staircase') {
          div.classList.add('staircase-pattern', 'staircase-element');

          // Build 3D stairs
          const isHoriz = el.w >= el.h;
          const steps = 6;
          const isUp = el.stairDir !== 'down';
          for (let s = 0; s < steps; s++) {
            const step = document.createElement('div');
            step.className = 'stair-step-block staircase-pattern';
            step.style.backgroundColor = el.color;
            if (isHoriz) {
              step.style.width = (el.w / steps) + 'px';
              step.style.height = '100%';
              step.style.left = (s * (el.w / steps)) + 'px';
              step.style.top = '0';
            } else {
              step.style.width = '100%';
              step.style.height = (el.h / steps) + 'px';
              step.style.left = '0';
              step.style.top = (s * (el.h / steps)) + 'px';
            }
            const heightIdx = isUp ? (s + 1) : (steps - s);
            const zHeight = (heightIdx / steps) * 40;
            step.style.setProperty('--z-depth', `${zHeight}px`);
            step.style.transform = `translateZ(${zHeight}px)`;

            const sFaces = document.createElement('div');
            sFaces.className = 'faces';
            step.appendChild(sFaces);
            div.appendChild(step);
          }
        }
        if (el.type === 'door' || el.name === 'Door') div.classList.add('door-element');
        if (el.type === 'window' || el.name === 'Window') div.classList.add('window-element');

        // Check if this element has stair links
        const hasLinks = state.stairLinks.some(lk => lk.fromElId === el.id || lk.toElId === el.id);
        if (hasLinks) div.classList.add('stair-linked');

        // Check if this element has universal links
        const hasULinks = state.universalLinks.some(lk => lk.fromElId === el.id || lk.toElId === el.id);
        if (hasULinks) div.classList.add('universal-linked');

        div.id = 'el-' + el.id;
        let baseZ = 12;
        if (el.isStairs || el.type === 'Staircase') {
          baseZ += (el.stairElevation || 0);
        }
        const transformStr = state.is3D
          ? `rotate(${el.r || 0}deg) translateZ(${baseZ}px)`
          : `rotate(${el.r || 0}deg)`;
        div.style.cssText = `left:${el.x}px;top:${el.y}px;width:${el.w}px;height:${el.h}px;background-color:${el.color};transform:${transformStr};z-index:${el.id === state.selectedId ? 100 : 1};`;

        const faces = document.createElement('div');
        faces.className = 'faces';
        div.appendChild(faces);

        // Shaped corridor rendering
        if (el.type && el.type.startsWith('Corridor-')) {
          div.classList.add('corridor-shaped');
          div.style.backgroundColor = 'transparent';
          div.style.border = 'none';
          div.style.outline = 'none';
          div.style.boxShadow = 'none';
          const svg = buildCorridorSvg(el);
          div.appendChild(svg);
        }

        // Stair badge
        if (hasLinks) {
          const links = state.stairLinks.filter(lk => lk.fromElId === el.id || lk.toElId === el.id);
          const badge = document.createElement('div');
          badge.className = 'stair-badge';
          const floorNums = new Set();
          links.forEach(lk => {
            const otherFloorId = lk.fromElId === el.id ? lk.toFloorId : lk.fromFloorId;
            const f = state.floors.find(fl => fl.id === otherFloorId);
            if (f) floorNums.add(f.name.replace('Floor', 'Fl').replace('Ground', 'G'));
          });
          badge.textContent = '🪜 ' + [...floorNums].join(', ');
          div.appendChild(badge);
        }

        // Universal link badge
        if (hasULinks) {
          const ulinks = state.universalLinks.filter(lk => lk.fromElId === el.id || lk.toElId === el.id);
          const ubadge = document.createElement('div');
          ubadge.className = 'universal-badge';
          const ufloorNums = new Set();
          ulinks.forEach(lk => {
            const otherFloorId = lk.fromElId === el.id ? lk.toFloorId : lk.fromFloorId;
            const otherElId = lk.fromElId === el.id ? lk.toElId : lk.fromElId;
            const f = state.floors.find(fl => fl.id === otherFloorId);
            const otherEl = getElById(otherElId);
            if (f) ufloorNums.add((otherEl ? otherEl.el.name : '?') + ' (' + f.name.replace('Floor', 'Fl').replace('Ground', 'G') + ')');
          });
          ubadge.textContent = '🔗 ' + [...ufloorNums].join(', ');
          div.appendChild(ubadge);
        }

        const isCorridor = el.type === 'Corridor' || (el.type && el.type.startsWith('Corridor-'));
        const isStair = el.isStairs || el.type === 'Staircase';
        const isDoorOrWindow = el.type === 'door' || el.type === 'window';

        if (!isCorridor && !isStair && !isDoorOrWindow) {
          const lbl = document.createElement('div');
          lbl.className = 'label';
          lbl.textContent = el.name;
          lbl.dataset.rot = el.r || 0;
          lbl.style.setProperty('--el-rot', `${el.r || 0}deg`);
          div.appendChild(lbl);
        }

        const dims = document.createElement('div');
        dims.className = 'dims-tag';
        dims.id = 'dims-' + el.id;
        dims.textContent = `${el.w} × ${el.h}`;
        div.appendChild(dims);

        ['nw', 'n', 'ne', 'w', 'e', 'sw', 's', 'se'].forEach(dir => {
          const h = document.createElement('div');
          h.className = 'resize ' + dir;
          h.onmousedown = e => startResize(e, el, dir);
          div.appendChild(h);
        });

        div.onmousedown = e => {
          state.currBlockId = block.id;
          if (state.is3D) {
            state.selectedId = el.id;
            state.selectedWallId = null;
            renderAll();
            e.stopPropagation();
            return;
          }
          startDrag(e, el);
        };
        fragment.appendChild(div);
      });
    });
  }
  canvas.appendChild(fragment);
  applyCanvasTransform();
}

function updatePropsPanel() {
  const panel = document.getElementById('propsPanel');
  const el = getSelected();
  if (!el) { panel.style.display = 'none'; return; }
  panel.style.display = 'block';
  document.getElementById('pname').value = el.name;
  // Show shape type badge for shaped corridors
  let shapeInfo = document.getElementById('pShapeInfo');
  if (!shapeInfo) {
    shapeInfo = document.createElement('div');
    shapeInfo.id = 'pShapeInfo';
    shapeInfo.style.cssText = 'font-size:11px;background:#e8f4fd;border:1px solid #a0c4e8;border-radius:4px;padding:4px 8px;margin-bottom:8px;color:#1a6aaa;font-weight:600;display:none;';
    document.getElementById('pname').parentNode.insertBefore(shapeInfo, document.getElementById('pname'));
  }
  const shapeNames = { 'Corridor-Triangle': '▲ Triangle Corridor', 'Corridor-Circle': '◯ Oval Corridor', 'Corridor-Cross': '✚ Cross Corridor' };
  if (shapeNames[el.type]) {
    shapeInfo.textContent = shapeNames[el.type];
    shapeInfo.style.display = 'block';
  } else {
    shapeInfo.style.display = 'none';
  }
  document.getElementById('pwidth').value = el.w;
  document.getElementById('pheight').value = el.h;
  document.getElementById('px').value = el.x;
  document.getElementById('py').value = el.y;
  document.getElementById('prot').value = el.r;
  document.getElementById('pcolor').value = el.color;
  document.getElementById('pisStairs').checked = el.isStairs || false;

  const stairDirRow = document.getElementById('stairDirRow');
  const stairElevationRow = document.getElementById('stairElevationRow');
  if (el.type === 'Staircase' || el.isStairs) {
    stairDirRow.style.display = 'flex';
    stairElevationRow.style.display = 'flex';
    document.getElementById('pstairDir').value = el.stairDir || 'up';
    document.getElementById('pstairElevation').value = el.stairElevation || 0;
  } else {
    stairDirRow.style.display = 'none';
    stairElevationRow.style.display = 'none';
  }

  // Show vertical-linking section for stairs, elevators, and Stair Hall junctions
  const stairSection = document.getElementById('stairLinkSection');
  if (isVerticalConnector(el)) {
    stairSection.style.display = 'block';
    renderCurrentStairLinks(el);
  } else {
    stairSection.style.display = 'none';
  }

  // Show universal linking section for ALL elements
  renderCurrentUniversalLinks(el);
}

function renderCurrentStairLinks(el) {
  const container = document.getElementById('stairCurrentLinks');
  container.innerHTML = '';
  const links = state.stairLinks.filter(lk => lk.fromElId === el.id || lk.toElId === el.id);
  if (links.length === 0) {
    container.innerHTML = '<div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">No connections yet.</div>';
    return;
  }
  links.forEach(lk => {
    const isFrom = lk.fromElId === el.id;
    const otherElId = isFrom ? lk.toElId : lk.fromElId;
    const otherFloorId = isFrom ? lk.toFloorId : lk.fromFloorId;
    const otherEl = getElById(otherElId);
    const otherFloor = state.floors.find(f => f.id === otherFloorId);
    const chip = document.createElement('div');
    chip.className = 'stair-link-chip';
    chip.innerHTML = `<i data-lucide="chevrons-up-down" style="width:12px;height:12px;color:var(--accent-purple);"></i> <span>${otherEl ? otherEl.el.name : '?'} on ${otherFloor ? otherFloor.name : '?'}</span>
      <span class="remove-link" onclick="removeStairLink(${JSON.stringify(lk).replace(/"/g, "'")})">✕</span>`;
    container.appendChild(chip);
  });
}

function renderStairLinksPanel() {
  const panel = document.getElementById('stairLinksList');
  if (state.stairLinks.length === 0) {
    panel.innerHTML = '<div class="empty-state">No vertical connections yet. Select a Staircase, Elevator, or Stair Hall on the canvas.</div>';
    return;
  }
  panel.innerHTML = '';
  state.stairLinks.forEach((lk, i) => {
    const fromEl = getElById(lk.fromElId);
    const toEl = getElById(lk.toElId);
    const fromFloor = state.floors.find(f => f.id === lk.fromFloorId);
    const toFloor = state.floors.find(f => f.id === lk.toFloorId);
    const row = document.createElement('div');
    row.className = 'stair-link-row';
    row.innerHTML = `<span class="link-icon"><i data-lucide="chevrons-up-down" style="width:14px;height:14px;color:var(--accent-purple);"></i></span>
      <span style="flex:1;font-size:12px;line-height:1.4;">
        <b>${fromEl ? fromEl.el.name : '?'}</b> (${fromFloor ? fromFloor.name : '?'})
        <br><span style="color:var(--text-muted);">↕</span> <b>${toEl ? toEl.el.name : '?'}</b> (${toFloor ? toFloor.name : '?'})
      </span>
      <button class="danger" style="padding:4px;width:24px;height:24px;" onclick="removeStairLinkByIndex(${i})"><i data-lucide="trash-2"></i></button>`;
    panel.appendChild(row);
  });
}

function renderCurrentUniversalLinks(el) {
  const container = document.getElementById('universalCurrentLinks');
  container.innerHTML = '';
  const links = state.universalLinks.filter(lk => lk.fromElId === el.id || lk.toElId === el.id);
  if (links.length === 0) {
    container.innerHTML = '<div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">No element links yet.</div>';
    return;
  }
  links.forEach(lk => {
    const isFrom = lk.fromElId === el.id;
    const otherElId = isFrom ? lk.toElId : lk.fromElId;
    const otherFloorId = isFrom ? lk.toFloorId : lk.fromFloorId;
    const otherEl = getElById(otherElId);
    const otherFloor = state.floors.find(f => f.id === otherFloorId);
    const chip = document.createElement('div');
    chip.className = 'universal-link-chip';
    chip.innerHTML = `<i data-lucide="link-2" style="width:12px;height:12px;color:var(--accent-teal);"></i> <span>${otherEl ? otherEl.el.name : '?'} on ${otherFloor ? otherFloor.name : '?'}</span>
      <span class="remove-link" onclick="removeUniversalLinkById(${lk.id})">✕</span>`;
    container.appendChild(chip);
  });
}

function renderUniversalLinksPanel() {
  const panel = document.getElementById('universalLinksList');
  if (state.universalLinks.length === 0) {
    panel.innerHTML = '<div class="empty-state">No element links yet. Select any element and use \"Link to Element\".</div>';
    return;
  }
  panel.innerHTML = '';
  state.universalLinks.forEach((lk, i) => {
    const fromEl = getElById(lk.fromElId);
    const toEl = getElById(lk.toElId);
    const fromFloor = state.floors.find(f => f.id === lk.fromFloorId);
    const toFloor = state.floors.find(f => f.id === lk.toFloorId);
    const row = document.createElement('div');
    row.className = 'universal-link-row';
    row.innerHTML = `<span class="link-icon"><i data-lucide="link-2" style="width:14px;height:14px;color:var(--accent-teal);"></i></span>
      <span style="flex:1;font-size:12px;line-height:1.4;">
        <b>${fromEl ? fromEl.el.name : '?'}</b> (${fromFloor ? fromFloor.name : '?'})
        <br><span style="color:var(--text-muted);">↔</span> <b>${toEl ? toEl.el.name : '?'}</b> (${toFloor ? toFloor.name : '?'})
      </span>
      <button class="danger" style="padding:4px;width:24px;height:24px;" onclick="removeUniversalLinkByIndex(${i})"><i data-lucide="trash-2"></i></button>`;
    panel.appendChild(row);
  });
}
