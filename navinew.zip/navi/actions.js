/* =================================================================
   ACTIONS
================================================================= */
window.addBuilding = function () {
  pushHistory();
  const id = Date.now();
  state.buildings.push({ id, name: 'Building ' + (state.buildings.length + 1) });
  state.currBuildingId = id;
  state.currFloorId = null;
  state.currBlockId = null;
  renderAll();
  showToast('Building added');
};

window.renameBuilding = function (e, id) {
  e.stopPropagation();
  const bldg = state.buildings.find(b => b.id === id);
  if (!bldg) return;
  const newName = prompt("Enter new building name:", bldg.name);
  if (newName && newName.trim() !== "") {
    pushHistory();
    bldg.name = newName.trim();
    renderAll();
    showToast("Building renamed");
  }
};

window.renameFloor = function (e, id) {
  e.stopPropagation();
  const f = state.floors.find(f => f.id === id);
  if (!f) return;
  const newName = prompt("Enter new floor name:", f.name);
  if (newName && newName.trim() !== "") {
    pushHistory();
    f.name = newName.trim();
    renderAll();
    showToast("Floor renamed");
  }
};

window.renameBlock = function (e, floorId, blockId) {
  e.stopPropagation();
  const f = state.floors.find(fl => fl.id === floorId);
  if (!f) return;
  const b = f.blocks.find(bl => bl.id === blockId);
  if (!b) return;
  const newName = prompt("Enter new block name:", b.name);
  if (newName && newName.trim() !== "") {
    pushHistory();
    b.name = newName.trim();
    renderAll();
    showToast("Block renamed");
  }
};

window.deleteBuilding = function (e, id) {
  e.stopPropagation();
  if (state.buildings.length <= 1) {
    showToast("Cannot delete the last building.");
    return;
  }
  if (!confirm("Are you sure you want to delete this building and all its floors?")) return;

  pushHistory();
  const deletedFloorIds = state.floors.filter(f => f.buildingId === id).map(f => f.id);

  state.buildings = state.buildings.filter(b => b.id !== id);
  state.floors = state.floors.filter(f => f.buildingId !== id);

  state.stairLinks = state.stairLinks.filter(lk => !deletedFloorIds.includes(lk.fromFloorId) && !deletedFloorIds.includes(lk.toFloorId));
  state.universalLinks = state.universalLinks.filter(lk => !deletedFloorIds.includes(lk.fromFloorId) && !deletedFloorIds.includes(lk.toFloorId));
  state.walls = state.walls.filter(w => !deletedFloorIds.includes(w.floorId));

  if (state.currBuildingId === id) {
    state.currBuildingId = state.buildings[0].id;
    const bldgFloors = state.floors.filter(f => f.buildingId === state.currBuildingId);
    if (bldgFloors.length > 0) {
      state.currFloorId = bldgFloors[0].id;
      state.currBlockId = bldgFloors[0].blocks[0].id;
    } else {
      state.currFloorId = null;
      state.currBlockId = null;
    }
  }
  renderAll();
  showToast("Building deleted");
};

window.moveFloor = function (e, floorId, direction) {
  e.stopPropagation();
  const floor = state.floors.find(f => f.id === floorId);
  if (!floor) return;

  const buildingFloors = state.floors.filter(f => f.buildingId === floor.buildingId);
  const currentOrderIndex = buildingFloors.findIndex(f => f.id === floorId);
  const targetOrderIndex = currentOrderIndex + direction;

  if (targetOrderIndex < 0 || targetOrderIndex >= buildingFloors.length) return;

  pushHistory();
  const reordered = [...buildingFloors];
  const [moved] = reordered.splice(currentOrderIndex, 1);
  reordered.splice(targetOrderIndex, 0, moved);

  const queuesByBuilding = new Map();
  queuesByBuilding.set(floor.buildingId, reordered);
  state.floors = state.floors.map(existing => {
    if (existing.buildingId !== floor.buildingId) return existing;
    return queuesByBuilding.get(floor.buildingId).shift();
  });

  state.currBuildingId = moved.buildingId;
  state.currFloorId = moved.id;
  state.currBlockId = moved.blocks[0]?.id || state.currBlockId;
  state.selectedId = null;
  renderAll();
  showToast("Floor moved");
};

window.deleteFloor = function (e, id) {
  e.stopPropagation();
  const f = state.floors.find(f => f.id === id);
  if (!f) return;
  const bldgFloors = state.floors.filter(fl => fl.buildingId === f.buildingId);
  if (bldgFloors.length <= 1) {
    showToast("Cannot delete the last floor of a building.");
    return;
  }
  if (!confirm("Are you sure you want to delete this floor and all its contents?")) return;

  pushHistory();
  state.floors = state.floors.filter(fl => fl.id !== id);
  state.stairLinks = state.stairLinks.filter(lk => lk.fromFloorId !== id && lk.toFloorId !== id);
  state.universalLinks = state.universalLinks.filter(lk => lk.fromFloorId !== id && lk.toFloorId !== id);
  state.walls = state.walls.filter(w => w.floorId !== id);

  if (state.currFloorId === id) {
    const remainingFloors = state.floors.filter(fl => fl.buildingId === f.buildingId);
    state.currFloorId = remainingFloors[0].id;
    state.currBlockId = remainingFloors[0].blocks[0].id;
  }
  renderAll();
  showToast("Floor deleted");
};

window.deleteBlock = function (e, floorId, blockId) {
  e.stopPropagation();
  const f = state.floors.find(fl => fl.id === floorId);
  if (!f) return;
  if (f.blocks.length <= 1) {
    showToast("Cannot delete the last block of a floor.");
    return;
  }
  if (!confirm("Are you sure you want to delete this block and all its elements?")) return;

  pushHistory();
  const block = f.blocks.find(b => b.id === blockId);
  if (block) {
    const elIds = block.elements.map(el => el.id);
    state.stairLinks = state.stairLinks.filter(lk => !elIds.includes(lk.fromElId) && !elIds.includes(lk.toElId));
    state.universalLinks = state.universalLinks.filter(lk => !elIds.includes(lk.fromElId) && !elIds.includes(lk.toElId));
  }

  f.blocks = f.blocks.filter(b => b.id !== blockId);
  if (state.currBlockId === blockId) {
    state.currBlockId = f.blocks[0].id;
  }
  renderAll();
  showToast("Block deleted");
};

window.addFloor = function () {
  pushHistory();
  const id = Date.now();
  const bldgFloors = state.floors.filter(f => f.buildingId === state.currBuildingId);
  const newFloorName = bldgFloors.length === 0 ? 'Ground Floor' : 'Floor ' + bldgFloors.length;
  state.floors.push({ id, buildingId: state.currBuildingId, name: newFloorName, blocks: [{ id: id + 1, name: 'Block A', elements: [] }] });
  state.currFloorId = id;
  state.currBlockId = id + 1;
  renderAll();
  showToast('Floor added');
};

window.addBlock = function () {
  const floor = curFloor();
  if (!floor) { showToast('Add a floor first'); return; }
  pushHistory();
  const id = Date.now();
  floor.blocks.push({ id, name: 'Block ' + String.fromCharCode(65 + floor.blocks.length), elements: [] });
  state.currBlockId = id; renderAll();
};

window.addEl = function (type, w, h, color, defaultName) {
  const block = curBlock();
  if (!block) { showToast('Add a floor and block first'); return; }
  pushHistory();
  const id = Date.now();
  const newEl = { id, type, name: defaultName || type, x: 20, y: 20, w, h, r: 0, color, isStairs: false };
  block.elements.push(newEl);
  state.selectedId = id; renderAll();
};

window.addRoom = function () {
  const type = document.getElementById('roomType').value;
  const map = {
    Room: [150, 100, '#fff'],
    Classroom: [200, 160, '#eef7fa'],
    Office: [120, 100, '#f5f5dc'],
    Corridor: [300, 60, '#f0f0f0'],
    'Corridor-Square': [200, 200, '#e8f4fd'],
    'Corridor-Rect': [280, 160, '#e8f4fd'],
    'Corridor-Circle': [200, 200, '#e8f4fd'],
    'Corridor-Triangle': [220, 180, '#e8f4fd'],
    'Corridor-L': [220, 220, '#e8f4fd'],
    'Corridor-T': [240, 200, '#e8f4fd'],
    'Corridor-U': [240, 220, '#e8f4fd'],
    'Corridor-H': [240, 220, '#e8f4fd'],
    'Corridor-E': [220, 220, '#e8f4fd'],
    'Corridor-Y': [220, 240, '#e8f4fd'],
    'Corridor-Cross': [220, 220, '#e8f4fd'],
    'Corridor-Courtyard': [240, 240, '#e8f4fd'],
    Staircase: [100, 140, '#eafaf1'],
    Restroom: [100, 80, '#e8f5e9'],
    Hall: [250, 180, '#fff9e6'],
    Elevator: [80, 80, '#d5e8f5'],
  };
  const [w, h, color] = map[type] || [150, 100, '#fff'];
  window.addEl(type, w, h, color, type);
  const created = curBlock().elements[curBlock().elements.length - 1];
  if (type === 'Staircase') created.isStairs = true;
  renderAll();
};
window.buildStairHall = function () {
  const block = curBlock();
  if (!block) { showToast("Add a floor first"); return; }

  const countInput = document.getElementById("stairHallCount");
  const requested = parseInt(countInput?.value, 10);
  const stairCount = Math.max(1, Math.min(12, Number.isFinite(requested) ? requested : 4));

  pushHistory();

  const idBase = Date.now();
  const existingEls = block.elements;
  const maxBottom = existingEls.reduce((max, el) => Math.max(max, (el.y || 0) + (el.h || 0)), 0);
  const hall = {
    id: idBase,
    type: "Hall",
    name: "Stair Hall",
    x: 190,
    y: Math.max(150, maxBottom + 150),
    w: 280,
    h: 180,
    r: 0,
    color: "#fff9e6",
    isStairs: false
  };

  block.elements.push(hall);

  const stairW = 96;
  const stairH = 96;

  for (let i = 0; i < stairCount; i++) {
    const side = i % 4;
    const lane = Math.floor(i / 4);
    let x = hall.x;
    let y = hall.y;

    if (side === 0) {
      x = hall.x + 20 + (lane % 3) * 90;
      y = hall.y - stairH;
    } else if (side === 1) {
      x = hall.x + hall.w;
      y = hall.y + 10 + (lane % 2) * 84;
    } else if (side === 2) {
      x = hall.x + 20 + (lane % 3) * 90;
      y = hall.y + hall.h;
    } else {
      x = hall.x - stairW;
      y = hall.y + 10 + (lane % 2) * 84;
    }

    const stair = {
      id: idBase + i + 1,
      type: "Staircase",
      name: "Stair " + (i + 1),
      x,
      y,
      w: stairW,
      h: stairH,
      r: 0,
      color: "#eafaf1",
      isStairs: true,
      stairDir: i === 0 ? "down" : "up",
      stairElevation: 0
    };

    block.elements.push(stair);
    state.stairLinks.push({
      fromElId: hall.id,
      fromFloorId: state.currFloorId,
      fromBlockId: state.currBlockId,
      toElId: stair.id,
      toFloorId: state.currFloorId,
      toBlockId: state.currBlockId
    });
  }

  state.selectedId = hall.id;
  renderAll();
  showToast("Stair Hall created with " + stairCount + " stair" + (stairCount === 1 ? "" : "s"));
};

window.deleteSelected = function () {
  if (!state.selectedId) return;
  pushHistory();
  // Remove any stair links involving this element
  state.stairLinks = state.stairLinks.filter(lk => lk.fromElId !== state.selectedId && lk.toElId !== state.selectedId);
  // Remove any universal links involving this element
  state.universalLinks = state.universalLinks.filter(lk => lk.fromElId !== state.selectedId && lk.toElId !== state.selectedId);

  for (let b of (curFloor()?.blocks || [])) {
    b.elements = b.elements.filter(e => e.id !== state.selectedId);
  }

  state.selectedId = null; renderAll();
};

window.duplicateSelected = function () {
  const el = getSelected(); if (!el) return;
  pushHistory();
  const clone = JSON.parse(JSON.stringify(el));
  clone.id = Date.now(); clone.x += 20; clone.y += 20; clone.name += ' (Copy)';

  const b = (curFloor()?.blocks || []).find(block => block.elements.some(e => e.id === el.id)) || curBlock();
  if (b) b.elements.push(clone);

  state.selectedId = clone.id; renderAll();
};

/* =================================================================
   STAIR LINKING
================================================================= */
let _pendingStairSource = null; // {elId, floorId, blockId}

window.openLinkThisStair = function () {
  const el = getSelected();
  if (!el) return;
  _pendingStairSource = { elId: el.id, floorId: state.currFloorId, blockId: state.currBlockId };
  openStairLinkModal(_pendingStairSource);
};

function openStairLinkModal(source) {
  const sourceRec = getElById(source.elId);
  const sourceFloor = state.floors.find(f => f.id === source.floorId);
  document.getElementById('slSourceName').textContent = sourceRec ? sourceRec.el.name : '?';
  document.getElementById('slSourceFloor').textContent = sourceFloor ? sourceFloor.name : '?';

  // Populate target floors (including current)
  const tfSelect = document.getElementById('slTargetFloor');
  tfSelect.innerHTML = '';
  state.floors.forEach(f => {
    const opt = document.createElement('option');
    opt.value = f.id; opt.textContent = f.name;
    tfSelect.appendChild(opt);
  });

  populateTargetStairs();
  document.getElementById('stairLinkModal').classList.remove('hidden');
}

window.populateTargetStairs = function () {
  const floorId = parseInt(document.getElementById('slTargetFloor').value);
  const floor = state.floors.find(f => f.id === floorId);
  const tsSelect = document.getElementById('slTargetStair');
  tsSelect.innerHTML = '';
  if (!floor) return;
  const stairs = [];
  floor.blocks.forEach(b => {
    b.elements.forEach(el => {
      if (isVerticalConnector(el) && el.id !== _pendingStairSource.elId) stairs.push({ el, blockId: b.id, floorId });
    });
  });
  if (stairs.length === 0) {
    const opt = document.createElement('option'); opt.value = ''; opt.textContent = '— No staircases, elevators, or Stair Halls on this floor —';
    tsSelect.appendChild(opt);
  } else {
    stairs.forEach(s => {
      const opt = document.createElement('option'); opt.value = s.el.id; opt.textContent = s.el.name;
      tsSelect.appendChild(opt);
    });
  }
};

window.confirmStairLink = function () {
  const toElId = parseInt(document.getElementById('slTargetStair').value);
  const toFloorId = parseInt(document.getElementById('slTargetFloor').value);
  if (!toElId) { alert('No target connector available on that floor.'); return; }

  const toFloor = state.floors.find(f => f.id === toFloorId);
  let toBlockId = null;
  toFloor.blocks.forEach(b => { if (b.elements.find(e => e.id === toElId)) toBlockId = b.id; });

  // Prevent duplicate
  const exists = state.stairLinks.some(lk =>
    (lk.fromElId === _pendingStairSource.elId && lk.toElId === toElId) ||
    (lk.fromElId === toElId && lk.toElId === _pendingStairSource.elId)
  );
  if (exists) { showToast('Link already exists!'); closeStairLinkModal(); return; }

  pushHistory();
  state.stairLinks.push({
    fromElId: _pendingStairSource.elId,
    fromFloorId: _pendingStairSource.floorId,
    fromBlockId: _pendingStairSource.blockId,
    toElId, toFloorId, toBlockId
  });
  closeStairLinkModal();
  renderAll();
  showToast('Vertical connector linked!');
};

window.closeStairLinkModal = function () {
  document.getElementById('stairLinkModal').classList.add('hidden');
};

window.removeStairLinkByIndex = function (i) {
  pushHistory();
  state.stairLinks.splice(i, 1);
  renderAll();
  showToast('Link removed');
};

window.removeStairLink = function (lkStr) {
  // lkStr came from JSON stringified with single quotes replaced
  // We'll match by fromElId+toElId
  try {
    const lk = typeof lkStr === 'object' ? lkStr : JSON.parse(lkStr.replace(/'/g, '"'));
    const idx = state.stairLinks.findIndex(l => l.fromElId === lk.fromElId && l.toElId === lk.toElId);
    if (idx >= 0) { pushHistory(); state.stairLinks.splice(idx, 1); renderAll(); showToast('Link removed'); }
  } catch (e) { console.error(e); }
};

window.openStairManager = function () {
  const content = document.getElementById('stairManagerContent');
  if (state.stairLinks.length === 0) {
    content.innerHTML = '<div class="path-empty">No stair connections have been created yet.</div>';
  } else {
    content.innerHTML = '';
    state.stairLinks.forEach((lk, i) => {
      const fromEl = getElById(lk.fromElId);
      const toEl = getElById(lk.toElId);
      const fromFloor = state.floors.find(f => f.id === lk.fromFloorId);
      const toFloor = state.floors.find(f => f.id === lk.toFloorId);
      const row = document.createElement('div');
      row.className = 'stair-link-row';
      row.innerHTML = `<span class="link-icon"><i data-lucide="chevrons-up-down" style="width:14px;height:14px;color:var(--accent-purple);"></i></span>
        <span style="flex:1;font-size:13px;">
          <b>${fromEl ? fromEl.el.name : '?'}</b> on ${fromFloor ? fromFloor.name : '?'}
          &nbsp;↔&nbsp;
          <b>${toEl ? toEl.el.name : '?'}</b> on ${toFloor ? toFloor.name : '?'}
        </span>
        <button class="danger" onclick="removeStairLinkByIndex(${i});openStairManager();"><i data-lucide="trash-2"></i> Remove</button>`;
      content.appendChild(row);
    });
  }
  document.getElementById('stairManagerModal').classList.remove('hidden');
  if (window.lucide) window.lucide.createIcons();
};

/* =================================================================
   UNIVERSAL ELEMENT LINKING
================================================================= */
let _pendingUniversalSource = null; // {elId, floorId, blockId}

window.openUniversalLinkModal = function () {
  const el = getSelected();
  if (!el) { showToast('Select an element first'); return; }
  _pendingUniversalSource = { elId: el.id, floorId: state.currFloorId, blockId: state.currBlockId };

  const sourceRec = getElById(el.id);
  const sourceFloor = state.floors.find(f => f.id === state.currFloorId);
  document.getElementById('ulSourceName').textContent = sourceRec ? sourceRec.el.name : '?';
  document.getElementById('ulSourceFloor').textContent = sourceFloor ? sourceFloor.name : '?';

  // Populate target floors (ALL floors including current)
  const tfSelect = document.getElementById('ulTargetFloor');
  tfSelect.innerHTML = '';
  state.floors.forEach(f => {
    const opt = document.createElement('option');
    opt.value = f.id; opt.textContent = f.name;
    tfSelect.appendChild(opt);
  });

  if (!tfSelect.options.length) {
    alert('No floors available.');
    return;
  }

  // Default to a different floor if available
  const otherFloor = state.floors.find(f => f.id !== state.currFloorId);
  if (otherFloor) tfSelect.value = otherFloor.id;

  populateUniversalTargets();
  document.getElementById('universalLinkModal').classList.remove('hidden');
};

window.populateUniversalTargets = function () {
  const floorId = parseInt(document.getElementById('ulTargetFloor').value);
  const floor = state.floors.find(f => f.id === floorId);
  const teSelect = document.getElementById('ulTargetElement');
  teSelect.innerHTML = '';
  if (!floor) return;
  const targets = [];
  floor.blocks.forEach(b => {
    b.elements.forEach(el => {
      // Exclude the source element itself
      if (_pendingUniversalSource && el.id === _pendingUniversalSource.elId) return;
      targets.push({ el, blockId: b.id, blockName: b.name, floorId });
    });
  });
  if (targets.length === 0) {
    const opt = document.createElement('option'); opt.value = ''; opt.textContent = '— No elements on this floor —';
    teSelect.appendChild(opt);
  } else {
    targets.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t.el.id;
      opt.textContent = `${t.el.name} (${t.el.type}) — ${t.blockName}`;
      teSelect.appendChild(opt);
    });
  }
};

window.confirmUniversalLink = function () {
  const toElId = parseInt(document.getElementById('ulTargetElement').value);
  const toFloorId = parseInt(document.getElementById('ulTargetFloor').value);
  if (!toElId) { alert('No target element available.'); return; }

  const toFloor = state.floors.find(f => f.id === toFloorId);
  let toBlockId = null;
  toFloor.blocks.forEach(b => { if (b.elements.find(e => e.id === toElId)) toBlockId = b.id; });

  // Prevent duplicate
  const exists = state.universalLinks.some(lk =>
    (lk.fromElId === _pendingUniversalSource.elId && lk.toElId === toElId) ||
    (lk.fromElId === toElId && lk.toElId === _pendingUniversalSource.elId)
  );
  // Also check stair links for duplicate
  const existsStair = state.stairLinks.some(lk =>
    (lk.fromElId === _pendingUniversalSource.elId && lk.toElId === toElId) ||
    (lk.fromElId === toElId && lk.toElId === _pendingUniversalSource.elId)
  );
  if (exists || existsStair) { showToast('Link already exists!'); closeUniversalLinkModal(); return; }

  pushHistory();
  state.universalLinks.push({
    id: Date.now(),
    fromElId: _pendingUniversalSource.elId,
    fromFloorId: _pendingUniversalSource.floorId,
    fromBlockId: _pendingUniversalSource.blockId,
    toElId, toFloorId, toBlockId
  });
  closeUniversalLinkModal();
  renderAll();
  showToast('Elements linked!');
};

window.closeUniversalLinkModal = function () {
  document.getElementById('universalLinkModal').classList.add('hidden');
};

window.removeUniversalLinkById = function (linkId) {
  pushHistory();
  state.universalLinks = state.universalLinks.filter(lk => lk.id !== linkId);
  renderAll();
  showToast('Link removed');
};

window.removeUniversalLinkByIndex = function (i) {
  pushHistory();
  state.universalLinks.splice(i, 1);
  renderAll();
  showToast('Link removed');
};

window.openUniversalLinkManager = function () {
  const content = document.getElementById('universalLinkManagerContent');
  if (state.universalLinks.length === 0) {
    content.innerHTML = '<div class="path-empty">No element links have been created yet.</div>';
  } else {
    content.innerHTML = '';
    state.universalLinks.forEach((lk, i) => {
      const fromEl = getElById(lk.fromElId);
      const toEl = getElById(lk.toElId);
      const fromFloor = state.floors.find(f => f.id === lk.fromFloorId);
      const toFloor = state.floors.find(f => f.id === lk.toFloorId);
      const row = document.createElement('div');
      row.className = 'universal-link-row';
      row.innerHTML = `<span class="link-icon"><i data-lucide="link-2" style="width:14px;height:14px;color:var(--accent-teal);"></i></span>
        <span style="flex:1;font-size:13px;">
          <b>${fromEl ? fromEl.el.name : '?'}</b> on ${fromFloor ? fromFloor.name : '?'}
          &nbsp;↔&nbsp;
          <b>${toEl ? toEl.el.name : '?'}</b> on ${toFloor ? toFloor.name : '?'}
        </span>
        <button class="danger" onclick="removeUniversalLinkByIndex(${i});openUniversalLinkManager();"><i data-lucide="trash-2"></i> Remove</button>`;
      content.appendChild(row);
    });
  }
  document.getElementById('universalLinkManagerModal').classList.remove('hidden');
  if (window.lucide) window.lucide.createIcons();
};
