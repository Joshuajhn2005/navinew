/* =================================================================
   DRAG & RESIZE (GPU optimized)
================================================================= */
function startDrag(e, el) {
  if (state.is3D) return;
  if (e.target.classList.contains('resize')) return;
  e.preventDefault();
  state.selectedId = el.id;
  document.querySelectorAll('.element').forEach(d => d.classList.remove('selected'));
  const div = e.currentTarget;
  div.classList.add('selected');
  updatePropsPanel();

  const startX = e.clientX, startY = e.clientY;
  const origX = el.x, origY = el.y;
  const rot = el.r || 0;
  div.classList.add('dragging');
  let rAF = null;

  const onMove = evt => {
    if (rAF) return;
    rAF = requestAnimationFrame(() => {
      let nx = origX + (evt.clientX - startX) / state.zoom;
      let ny = origY + (evt.clientY - startY) / state.zoom;
      if (document.getElementById('snapToggle').checked) {
        nx = Math.round(nx / state.gridSize) * state.gridSize;
        ny = Math.round(ny / state.gridSize) * state.gridSize;
      }
      div.style.transform = `translate3d(${nx - origX}px,${ny - origY}px,0) rotate(${rot}deg)`;
      const px = document.getElementById('px'); const py = document.getElementById('py');
      if (px) { px.value = Math.round(nx); py.value = Math.round(ny); }
      rAF = null;
    });
  };

  const onUp = evt => {
    if (rAF) cancelAnimationFrame(rAF);
    div.classList.remove('dragging');
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    let fx = origX + (evt.clientX - startX) / state.zoom;
    let fy = origY + (evt.clientY - startY) / state.zoom;
    if (document.getElementById('snapToggle').checked) {
      fx = Math.round(fx / state.gridSize) * state.gridSize;
      fy = Math.round(fy / state.gridSize) * state.gridSize;
    }
    el.x = fx; el.y = fy;
    div.style.transform = `rotate(${rot}deg)`;
    div.style.left = el.x + 'px'; div.style.top = el.y + 'px';
    if (el.x !== origX || el.y !== origY) { pushHistory(); autoExpandCanvas(); }
  };

  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
}

function startResize(e, el, dir) {
  if (state.is3D) return;
  e.stopPropagation(); e.preventDefault();
  const startX = e.clientX, startY = e.clientY;
  const origX = el.x, origY = el.y, origW = el.w, origH = el.h;
  const div = document.getElementById('el-' + el.id);
  div.classList.add('resizing');
  const dimTag = document.getElementById('dims-' + el.id);

  const onMove = evt => {
    const dx = (evt.clientX - startX) / state.zoom;
    const dy = (evt.clientY - startY) / state.zoom;

    // Horizontal
    if (dir.includes('e')) {
      el.w = Math.max(20, snap(origW + dx));
    }
    if (dir.includes('w')) {
      const newW = Math.max(20, snap(origW - dx));
      el.x = origX + (origW - newW);
      el.w = newW;
    }
    // Vertical
    if (dir.includes('s')) {
      el.h = Math.max(20, snap(origH + dy));
    }
    if (dir.includes('n')) {
      const newH = Math.max(20, snap(origH - dy));
      el.y = origY + (origH - newH);
      el.h = newH;
    }

    div.style.left = el.x + 'px'; div.style.top = el.y + 'px';
    div.style.width = el.w + 'px'; div.style.height = el.h + 'px';
    // Live-update shaped corridor SVG during resize
    if (el.type === 'Corridor-Triangle' || el.type === 'Corridor-Circle' || el.type === 'Corridor-Cross') {
      const oldSvg = div.querySelector('svg');
      if (oldSvg) oldSvg.remove();
      const newSvg = buildCorridorSvg(el);
      div.insertBefore(newSvg, div.firstChild);
    }
    if (dimTag) dimTag.textContent = `${Math.round(el.w)} × ${Math.round(el.h)}`;
    const pw = document.getElementById('pwidth'), ph = document.getElementById('pheight');
    const px = document.getElementById('px'), py = document.getElementById('py');
    if (pw) { pw.value = Math.round(el.w); ph.value = Math.round(el.h); }
    if (px) { px.value = Math.round(el.x); py.value = Math.round(el.y); }
  };

  const onUp = () => {
    div.classList.remove('resizing');
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    if (el.w !== origW || el.h !== origH || el.x !== origX || el.y !== origY) {
      pushHistory(); autoExpandCanvas();
    }
  };

  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
}

/* =================================================================
   ZOOM
================================================================= */
function applyCanvasTransform() {
  canvasWrap.style.transform = `translate(${state.panX}px, ${state.panY}px) scale(${state.zoom})`;
  const viewport = document.getElementById('canvas3dViewport');
  if (viewport) {
    if (state.is3D) {
      const rx = state.rotX !== undefined ? state.rotX : 52;
      const rz = state.rotZ !== undefined ? state.rotZ : -30;
      viewport.style.transform = `rotateX(${rx}deg) rotateZ(${rz}deg)`;
      viewport.style.setProperty('--cam-rx', `${rx}deg`);
      viewport.style.setProperty('--cam-rz', `${rz}deg`);
    } else {
      viewport.style.transform = '';
      viewport.style.removeProperty('--cam-rx');
      viewport.style.removeProperty('--cam-rz');
    }
  }
}

/* Canvas resize */
window.resizeCanvas = function () {
  const w = Math.max(800, parseInt(document.getElementById('canvasW').value) || 3000);
  const h = Math.max(600, parseInt(document.getElementById('canvasH').value) || 2400);
  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
};

/* Auto-expand canvas when elements are dragged near edges */
function autoExpandCanvas() {
  let maxX = 0, maxY = 0;
  const block = curBlock();
  block.elements.forEach(el => {
    maxX = Math.max(maxX, el.x + el.w + 100);
    maxY = Math.max(maxY, el.y + el.h + 100);
  });
  const curW = parseInt(canvas.style.width) || 3000;
  const curH = parseInt(canvas.style.height) || 2400;
  if (maxX > curW || maxY > curH) {
    const newW = Math.max(curW, Math.ceil(maxX / 200) * 200);
    const newH = Math.max(curH, Math.ceil(maxY / 200) * 200);
    canvas.style.width = newW + 'px';
    canvas.style.height = newH + 'px';
    document.getElementById('canvasW').value = newW;
    document.getElementById('canvasH').value = newH;
  }
}

window.updateZoom = function () {
  const sl = document.getElementById('zoomSlider');
  state.zoom = parseFloat(sl.value);
  document.getElementById('zoomVal').textContent = Math.round(state.zoom * 100) + '%';
  applyCanvasTransform();
};

/* ---- Canvas panning: left-click drag on empty canvas, middle-mouse anywhere, scroll to zoom ---- */
(function () {
  const container = document.getElementById('canvasContainer');
  let isPanning = false, panStartX = 0, panStartY = 0, panOrigX = 0, panOrigY = 0;
  let isRotating = false, rotStartX = 0, rotStartY = 0, rotOrigX = 0, rotOrigZ = 0;

  function isCanvasBg(target) {
    // True when the click lands on empty canvas background (not a room/wall/button)
    return target === canvas ||
      target === canvasWrap ||
      target === container ||
      target.id === 'wallDrawPreview' ||
      target.id === 'pathArrowSvg';
  }

  function startPan(e) {
    if (state.is3D && e.button === 0) {
      isRotating = true;
      rotStartX = e.clientX;
      rotStartY = e.clientY;
      rotOrigX = state.rotX !== undefined ? state.rotX : 52;
      rotOrigZ = state.rotZ !== undefined ? state.rotZ : -30;
      container.style.cursor = 'grab';
    } else {
      isPanning = true;
      panStartX = e.clientX;
      panStartY = e.clientY;
      panOrigX = state.panX;
      panOrigY = state.panY;
      container.style.cursor = 'grabbing';
    }
    container.classList.add('is-dragging');
    window._lastPanMoved = false;
    e.preventDefault();
    e.stopPropagation();
  }

  function stopPan() {
    isPanning = false;
    isRotating = false;
    container.style.cursor = '';
    container.classList.remove('is-dragging');
  }

  // Track whether mouse moved during mousedown so click handler can ignore pan-drags
  window._lastPanMoved = false;

  // Left-click on empty canvas background → pan or rotate
  // Middle-click anywhere → pan
  container.addEventListener('mousedown', function (e) {
    if (e.button === 1) {
      // Middle mouse — always pan
      startPan(e);
    } else if (e.button === 0 && isCanvasBg(e.target) && !_wallToolActive) {
      // Left click on empty background — pan (not on a room/wall element)
      startPan(e);
    }
  }, true); // capture phase so it fires before element handlers

  window.addEventListener('mousemove', function (e) {
    if (isRotating) {
      const dx = e.clientX - rotStartX, dy = e.clientY - rotStartY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) window._lastPanMoved = true;
      state.rotZ = rotOrigZ - dx * 0.5;
      state.rotX = rotOrigX - dy * 0.5;
      state.rotX = Math.max(0, Math.min(90, state.rotX));
      applyCanvasTransform();
    } else if (isPanning) {
      const dx = e.clientX - panStartX, dy = e.clientY - panStartY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) window._lastPanMoved = true;
      state.panX = panOrigX + dx;
      state.panY = panOrigY + dy;
      applyCanvasTransform();
    }
  });

  window.addEventListener('mouseup', function () {
    stopPan();
  });

  // Prevent context menu on middle click
  container.addEventListener('contextmenu', function (e) {
    if (e.button === 1) e.preventDefault();
  });

  // Mouse wheel → zoom centred on cursor
  container.addEventListener('wheel', function (e) {
    e.preventDefault();
    const rect = container.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const oldZoom = state.zoom;
    const factor = e.deltaY < 0 ? 1.1 : 0.9;
    const newZoom = Math.min(3, Math.max(0.15, oldZoom * factor));
    state.panX = mx - (mx - state.panX) * (newZoom / oldZoom);
    state.panY = my - (my - state.panY) * (newZoom / oldZoom);
    state.zoom = newZoom;
    const sl = document.getElementById('zoomSlider');
    if (sl) { sl.value = state.zoom; }
    document.getElementById('zoomVal').textContent = Math.round(state.zoom * 100) + '%';
    applyCanvasTransform();
  }, { passive: false });
})();

/* =================================================================
   PROPERTY LISTENERS
================================================================= */
document.getElementById('pname').oninput = function () { const el = getSelected(); if (el) { el.name = this.value; renderCanvas(); } };
document.getElementById('pwidth').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.w = parseInt(this.value); renderCanvas(); } };
document.getElementById('pheight').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.h = parseInt(this.value); renderCanvas(); } };
document.getElementById('px').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.x = parseInt(this.value); renderCanvas(); } };
document.getElementById('py').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.y = parseInt(this.value); renderCanvas(); } };
document.getElementById('prot').oninput = function () { const el = getSelected(); if (el) { el.r = parseInt(this.value); renderCanvas(); } };
document.getElementById('prot').onchange = function () { pushHistory(); };
document.getElementById('pstairDir').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.stairDir = this.value; renderCanvas(); } };
document.getElementById('pstairElevation').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.stairElevation = parseInt(this.value) || 0; renderCanvas(); } };
document.getElementById('pcolor').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.color = this.value; renderCanvas(); } };
document.getElementById('pisStairs').onchange = function () { pushHistory(); const el = getSelected(); if (el) { el.isStairs = this.checked; renderCanvas(); } };

canvas.addEventListener('click', function (e) {
  // Only deselect if this was a true click (not end of a pan drag)
  if (_lastPanMoved) return;
  if (e.target === canvas || e.target.id === 'wallDrawPreview' || e.target === canvasWrap) {
    state.selectedId = null;
    state.selectedWallId = null;
    renderAll();
  }
});

/* =================================================================
   WALL TOOL
================================================================= */
let _wallToolActive = false;

window.toggleWallTool = function () {
  if (state.is3D) {
    showToast('Cannot draw walls in 3D View');
    return;
  }
  _wallToolActive = !_wallToolActive;
  const btn = document.getElementById('wallToolBtn');
  const hint = document.getElementById('wallHint');
  if (_wallToolActive) {
    btn.classList.add('active');
    btn.textContent = '🧱 Drawing Wall…';
    hint.style.display = 'block';
    canvas.style.cursor = 'crosshair';
  } else {
    btn.classList.remove('active');
    btn.textContent = '🧱 Draw Wall';
    hint.style.display = 'none';
    canvas.style.cursor = '';
  }
};

window.deleteSelectedWall = function () {
  if (!state.selectedWallId) { showToast('Select a wall first'); return; }
  pushHistory();
  state.walls = state.walls.filter(w => w.id !== state.selectedWallId);
  state.selectedWallId = null;
  renderAll();
};

// Wall draw: mousedown on canvas when wall tool active
canvas.addEventListener('mousedown', function (e) {
  if (!_wallToolActive) return;
  if (state.is3D) return;
  if (e.target !== canvas && e.target.id !== 'wallDrawPreview') return;
  e.preventDefault();
  e.stopPropagation();

  const rect = canvas.getBoundingClientRect();
  let sx = (e.clientX - rect.left) / state.zoom;
  let sy = (e.clientY - rect.top) / state.zoom;
  if (document.getElementById('snapToggle').checked) {
    sx = Math.round(sx / state.gridSize) * state.gridSize;
    sy = Math.round(sy / state.gridSize) * state.gridSize;
  }

  const WALL_THICKNESS = 8; // fixed architectural thickness
  const preview = document.getElementById('wallDrawPreview');
  preview.style.display = 'block';
  preview.style.left = sx + 'px';
  preview.style.top = (sy - WALL_THICKNESS / 2) + 'px';
  preview.style.width = '0px';
  preview.style.height = WALL_THICKNESS + 'px';
  preview._wall = null;

  const onMove = ev => {
    let ex = (ev.clientX - rect.left) / state.zoom;
    let ey = (ev.clientY - rect.top) / state.zoom;
    if (document.getElementById('snapToggle').checked) {
      ex = Math.round(ex / state.gridSize) * state.gridSize;
      ey = Math.round(ey / state.gridSize) * state.gridSize;
    }
    const dx = ex - sx, dy = ey - sy;
    let wx, wy, ww, wh;
    // Snap to whichever axis is dominant; minimum 1px drag before choosing axis
    if (Math.abs(dx) >= Math.abs(dy)) {
      // Horizontal wall
      wx = Math.min(sx, ex);
      wy = sy - WALL_THICKNESS / 2;
      ww = Math.max(Math.abs(dx), 1);
      wh = WALL_THICKNESS;
    } else {
      // Vertical wall
      wx = sx - WALL_THICKNESS / 2;
      wy = Math.min(sy, ey);
      ww = WALL_THICKNESS;
      wh = Math.max(Math.abs(dy), 1);
    }
    preview.style.left = wx + 'px';
    preview.style.top = wy + 'px';
    preview.style.width = ww + 'px';
    preview.style.height = wh + 'px';
    preview._wall = { wx, wy, ww, wh };
  };

  const onUp = () => {
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    preview.style.display = 'none';
    const w = preview._wall;
    // Require at least 20px length to commit
    if (!w || (w.ww < 20 && w.wh < 20)) { showToast('Drag longer to draw a wall'); return; }
    pushHistory();
    state.walls.push({ id: Date.now(), floorId: state.currFloorId, x: Math.round(w.wx), y: Math.round(w.wy), w: Math.round(w.ww), h: Math.round(w.wh) });
    renderCanvas();
    showToast('Wall added — press Esc to exit wall mode');
  };

  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
});

function startWallDrag(e, wall) {
  if (state.is3D) return;
  e.preventDefault();
  const startX = e.clientX, startY = e.clientY;
  const origX = wall.x, origY = wall.y;

  const onMove = ev => {
    let nx = origX + (ev.clientX - startX) / state.zoom;
    let ny = origY + (ev.clientY - startY) / state.zoom;
    if (document.getElementById('snapToggle').checked) {
      nx = Math.round(nx / state.gridSize) * state.gridSize;
      ny = Math.round(ny / state.gridSize) * state.gridSize;
    }
    wall.x = nx; wall.y = ny;
    const div = document.getElementById('wall-' + wall.id);
    if (div) { div.style.left = nx + 'px'; div.style.top = ny + 'px'; }
  };

  const onUp = () => {
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    pushHistory();
  };
  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
}

function startWallResize(e, wall, axis) {
  if (state.is3D) return;
  e.stopPropagation(); e.preventDefault();
  const startX = e.clientX, startY = e.clientY;
  const origW = wall.w, origH = wall.h;

  const onMove = ev => {
    if (axis === 'h') {
      wall.w = Math.max(8, snap(origW + (ev.clientX - startX) / state.zoom));
    } else {
      wall.h = Math.max(8, snap(origH + (ev.clientY - startY) / state.zoom));
    }
    const div = document.getElementById('wall-' + wall.id);
    if (div) { div.style.width = wall.w + 'px'; div.style.height = wall.h + 'px'; }
  };

  const onUp = () => {
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    pushHistory();
  };
  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
}

/* =================================================================
   KEYBOARD
================================================================= */
window.addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
  if (e.key === 'Delete' || e.key === 'Backspace') {
    if (state.selectedWallId) { deleteSelectedWall(); }
    else { deleteSelected(); }
  }
  if (e.key === 'Escape') {
    state.selectedId = null;
    state.selectedWallId = null;
    if (_wallToolActive) toggleWallTool();
    renderAll();
  }
  if (e.ctrlKey && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); undo(); }
  if (e.ctrlKey && (e.key === 'y' || e.key === 'Y')) { e.preventDefault(); redo(); }
  if (e.ctrlKey && (e.key === 'd' || e.key === 'D')) { e.preventDefault(); duplicateSelected(); }
  if (state.selectedId) {
    const el = getSelected();
    if (e.key === 'ArrowRight') el.x += 1;
    if (e.key === 'ArrowLeft') el.x -= 1;
    if (e.key === 'ArrowUp') el.y -= 1;
    if (e.key === 'ArrowDown') el.y += 1;
    if (['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown'].includes(e.key)) { e.preventDefault(); renderCanvas(); updatePropsPanel(); }
  }
});

/* =================================================================
   EXPORT / IMPORT
================================================================= */
window.exportJSON = function () {
  const data = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify({ buildings: state.buildings, currBuildingId: state.currBuildingId, floors: state.floors, stairLinks: state.stairLinks, universalLinks: state.universalLinks, walls: state.walls }, null, 2));
  const a = document.createElement('a'); a.href = data; a.download = 'building_layout.json';
  document.body.appendChild(a); a.click(); a.remove();
  showToast('JSON downloaded');
};


window.importJSON = function () { document.getElementById('jsonFileInput').click(); };

window.handleJSONImport = function (event) {
  const file = event.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = function (e) {
    try {
      const parsed = JSON.parse(e.target.result);
      pushHistory();
      if (parsed.buildings) {
        state.buildings = parsed.buildings;
        state.currBuildingId = parsed.currBuildingId || parsed.buildings[0].id;
      } else {
        state.buildings = [{ id: 1, name: 'Main Building' }];
        state.currBuildingId = 1;
      }
      if (parsed.floors) {
        state.floors = parsed.floors;
        if (!parsed.buildings) state.floors.forEach(f => f.buildingId = 1);
        state.stairLinks = parsed.stairLinks || []; state.universalLinks = parsed.universalLinks || []; state.walls = parsed.walls || [];
      } else if (Array.isArray(parsed)) {
        state.floors = parsed;
        if (!parsed.buildings) state.floors.forEach(f => f.buildingId = 1);
        state.stairLinks = []; state.universalLinks = []; state.walls = [];
      } else throw new Error('Invalid format');
      state.currFloorId = state.floors[0].id;
      state.currBlockId = state.floors[0].blocks[0].id;
      state.selectedId = null;
      renderAll(); showToast('Layout loaded!');
    } catch (err) { alert('Invalid file: ' + err.message); }
  };
  reader.readAsText(file);
  event.target.value = '';
};

window.exportPDF = async function () {
  if (!window.jspdf) { alert('PDF library still loading...'); return; }
  const oldZoom = state.zoom; state.zoom = 1;
  applyCanvasTransform();
  document.querySelectorAll('.resize,.dims-tag').forEach(el => el.style.display = 'none');
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF('l', 'px', [1300, 1000]);
  await html2canvas(canvas, { scale: 2 }).then(c => {
    pdf.addImage(c.toDataURL('image/png'), 'PNG', 20, 20, 1200, 900);
    pdf.save('building_layout.pdf');
  });
  state.zoom = oldZoom; applyCanvasTransform(); renderAll();
};

/* =================================================================
   BOOT
================================================================= */
loadSavedState();
applyCanvasTransform();
renderAll();
