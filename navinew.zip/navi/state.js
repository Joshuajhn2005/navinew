/* =================================================================
   STATE
================================================================= */
let state = {
  buildings: [{ id: 1, name: 'Main Building' }],
  currBuildingId: 1,
  floors: [{
    id: 1, buildingId: 1, name: 'Ground Floor',
    blocks: [{ id: 101, name: 'Block A', elements: [] }]
  }],
  // stairLinks: [{fromElId, fromFloorId, fromBlockId, toElId, toFloorId, toBlockId}]
  stairLinks: [],
  // universalLinks: [{id, fromElId, fromFloorId, fromBlockId, toElId, toFloorId, toBlockId}]
  universalLinks: [],
  // walls: [{id, floorId, x, y, w, h}]  (per-floor walls)
  walls: [],
  currFloorId: 1,
  currBlockId: 101,
  selectedId: null,
  selectedWallId: null,
  zoom: 1,
  gridSize: 20,
  panX: 40,
  panY: 40,
  is3D: false,
  rotX: 52,
  rotZ: -30
};

let undoStack = [], redoStack = [];
const canvas = document.getElementById('canvas');
const canvasWrap = document.getElementById('canvasWrap');

/* =================================================================
   HELPERS
================================================================= */
const curFloor = () => state.floors.find(f => f.id === state.currFloorId);
const curBlock = () => {
  const f = curFloor();
  return f ? (f.blocks.find(b => b.id === state.currBlockId) || f.blocks[0]) : null;
};
const getSelected = () => {
  if (!state.selectedId) return null;
  const f = curFloor();
  if (!f) return null;
  for (let b of f.blocks) {
    let el = b.elements.find(e => e.id === state.selectedId);
    if (el) return el;
  }
  return null;
};

function allElements() {
  // Returns [{el, floorId, floorName, blockId, blockName}]
  const result = [];
  state.floors.forEach(f => {
    f.blocks.forEach(b => {
      b.elements.forEach(el => {
        result.push({ el, floorId: f.id, floorName: f.name, blockId: b.id, blockName: b.name });
      });
    });
  });
  return result;
}

function getElById(elId) {
  for (const f of state.floors) {
    for (const b of f.blocks) {
      const el = b.elements.find(e => e.id === elId);
      if (el) return { el, floorId: f.id, floorName: f.name, blockId: b.id, blockName: b.name };
    }
  }
  return null;
}

function isStairOrElevator(el) {
  return el.type === 'Staircase' || el.type === 'Elevator' || el.isStairs;
}

function isVerticalJunction(el) {
  const type = (el.type || '').toLowerCase();
  const name = (el.name || '').toLowerCase();
  return type === 'hall' || name.includes('stair hall') || name.includes('stair lobby') || name.includes('vertical junction');
}

function isVerticalConnector(el) {
  return isStairOrElevator(el) || isVerticalJunction(el);
}

function elLabel(rec) {
  return `${rec.el.name} (${rec.floorName} › ${rec.blockName})`;
}

function saveState() {
  try {
    localStorage.setItem('layoutProData', JSON.stringify({ buildings: state.buildings, currBuildingId: state.currBuildingId, floors: state.floors, stairLinks: state.stairLinks, universalLinks: state.universalLinks, walls: state.walls }));
    showToast('Saved');
  } catch (e) { showToast('Save failed'); }
}

function loadSavedState() {
  try {
    const raw = localStorage.getItem('layoutProData');
    if (!raw) return;
    const parsed = JSON.parse(raw);

    if (parsed.buildings) {
      state.buildings = parsed.buildings;
      state.currBuildingId = parsed.currBuildingId || parsed.buildings[0].id;
    } else {
      // Migrate old saves
      state.buildings = [{ id: 1, name: 'Main Building' }];
      state.currBuildingId = 1;
    }

    if (parsed.floors) {
      state.floors = parsed.floors;
      if (!parsed.buildings) state.floors.forEach(f => f.buildingId = 1); // Migration
      state.stairLinks = parsed.stairLinks || [];
      state.universalLinks = parsed.universalLinks || [];
      state.walls = parsed.walls || [];
      state.currFloorId = state.floors[0].id;
      state.currBlockId = state.floors[0].blocks[0].id;
      state.selectedId = null;
    } else if (Array.isArray(parsed)) {
      // legacy format
      state.floors = parsed;
      if (!parsed.buildings) state.floors.forEach(f => f.buildingId = 1); // Migration
      state.stairLinks = [];
      state.universalLinks = [];
      state.walls = [];
      state.currFloorId = state.floors[0].id;
      state.currBlockId = state.floors[0].blocks[0].id;
    }
    showToast('Layout restored');
  } catch (e) { console.warn('Restore failed', e); }
}

function pushHistory() {
  undoStack.push(JSON.stringify({ buildings: state.buildings, currBuildingId: state.currBuildingId, floors: state.floors, stairLinks: state.stairLinks, universalLinks: state.universalLinks, walls: state.walls }));
  if (undoStack.length > 30) undoStack.shift();
  redoStack = [];
  saveState();
}

window.undo = function () {
  if (!undoStack.length) return;
  redoStack.push(JSON.stringify({ buildings: state.buildings, currBuildingId: state.currBuildingId, floors: state.floors, stairLinks: state.stairLinks, universalLinks: state.universalLinks, walls: state.walls }));
  const s = JSON.parse(undoStack.pop());
  state.buildings = s.buildings || [{ id: 1, name: 'Main Building' }]; state.currBuildingId = s.currBuildingId || 1;
  state.floors = s.floors; state.stairLinks = s.stairLinks || []; state.universalLinks = s.universalLinks || []; state.walls = s.walls || [];
  renderAll();
};
window.redo = function () {
  if (!redoStack.length) return;
  undoStack.push(JSON.stringify({ buildings: state.buildings, currBuildingId: state.currBuildingId, floors: state.floors, stairLinks: state.stairLinks, universalLinks: state.universalLinks, walls: state.walls }));
  const s = JSON.parse(redoStack.pop());
  state.buildings = s.buildings || [{ id: 1, name: 'Main Building' }]; state.currBuildingId = s.currBuildingId || 1;
  state.floors = s.floors; state.stairLinks = s.stairLinks || []; state.universalLinks = s.universalLinks || []; state.walls = s.walls || [];
  renderAll();
};

window.confirmClearCanvas = function () {
  document.getElementById('clearCanvasModal').classList.remove('hidden');
};

window.clearCanvas = function () {
  document.getElementById('clearCanvasModal').classList.add('hidden');
  pushHistory(); // allow undo of the clear if needed
  state.buildings = [{ id: 1, name: 'Main Building' }];
  state.currBuildingId = 1;
  state.floors = [{ id: 1, buildingId: 1, name: 'Ground Floor', blocks: [{ id: 101, name: 'Block A', elements: [] }] }];
  state.stairLinks = [];
  state.universalLinks = [];
  state.walls = [];
  state.currFloorId = 1;
  state.currBlockId = 101;
  state.selectedId = null;
  state.selectedWallId = null;
  state.is3D = false; // Reset 3D mode when clearing canvas
  undoStack = [];
  redoStack = [];
  localStorage.removeItem('layoutProData');
  clearPathHighlights();
  renderAll();
  showToast('Canvas cleared');
};

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.opacity = 1;
  setTimeout(() => t.style.opacity = 0, 1800);
}

window.toggle3DMode = function () {
  state.is3D = !state.is3D;
  const container = document.getElementById('canvasContainer');
  const wrap = document.getElementById('canvasWrap');
  const btn = document.getElementById('viewModeBtn');
  const rotBtn = document.getElementById('rotate3DBtn');

  if (state.is3D) {
    if (_wallToolActive) {
      toggleWallTool();
    }
    container.classList.add('mode-3d');
    wrap.classList.add('mode-3d');
    btn.innerHTML = '<i data-lucide="layout"></i><span>2D Design</span>';
    // We allow selection in 3D now, but clear it initially
    state.selectedId = null;
    state.selectedWallId = null;
    renderAll();
    applyCanvasTransform();
    rotBtn.style.display = 'inline-flex';
    showToast('Switched to 3D View');
  } else {
    container.classList.remove('mode-3d');
    wrap.classList.remove('mode-3d');
    container.classList.remove('rotate-180');
    btn.innerHTML = '<i data-lucide="box"></i><span>3D View</span>';
    rotBtn.style.display = 'none';
    renderAll();
    applyCanvasTransform();
    showToast('Switched to 2D Design');
  }
  if (window.lucide) window.lucide.createIcons();
};

function snap(val) {
  if (!document.getElementById('snapToggle').checked) return val;
  return Math.round(val / state.gridSize) * state.gridSize;
}

window.state = state;
window.undoStack = undoStack;
window.redoStack = redoStack;
window.curFloor = curFloor;
window.curBlock = curBlock;
window.getSelected = getSelected;
window.allElements = allElements;
window.getElById = getElById;
