/* =================================================================
   PATH FINDER (Dijkstra across floors)
================================================================= */
/*
  Graph nodes: every element gets a unique node key = "elId"
  Edges:
    1. Same floor/block: two elements are adjacent if they physically overlap or touch (bounding boxes)
    2. Cross-floor: stairLinks connect stair elements between floors with a cost of 100 (floor-change penalty)

  Cost: Euclidean distance between element centers for same-floor edges, fixed cost for stair traversal.
*/

function rectCenter(el) {
  return { x: el.x + el.w / 2, y: el.y + el.h / 2 };
}

function rectsOverlapOrTouch(a, b, tolerance = 5) {
  return !(a.x + a.w + tolerance < b.x ||
    b.x + b.w + tolerance < a.x ||
    a.y + a.h + tolerance < b.y ||
    b.y + b.h + tolerance < a.y);
}

function dist(a, b) {
  const ca = rectCenter(a), cb = rectCenter(b);
  return Math.sqrt((ca.x - cb.x) ** 2 + (ca.y - cb.y) ** 2);
}

// Passage types — path can only travel THROUGH these element types
// (directly between two rooms, one of them must be a passage/door/elevator or they must share an open boundary)
const PASSAGE_TYPES = new Set(['corridor', 'door', 'elevator', 'staircase', 'hall', 'window']);

function isPassage(el) {
  const t = (el.type || '').toLowerCase();
  return PASSAGE_TYPES.has(t) || t.startsWith('corridor') || el.isStairs;
}

// Returns the shared edge region between two touching rects, or null if not touching
function getSharedEdge(a, b, tolerance = 8) {
  const aR = a.x + a.w, aB = a.y + a.h;
  const bR = b.x + b.w, bB = b.y + b.h;

  // Vertical shared edge (left-right)
  if (Math.abs(aR - b.x) <= tolerance || Math.abs(bR - a.x) <= tolerance) {
    const edgeX = Math.abs(aR - b.x) <= tolerance ? (aR + b.x) / 2 : (bR + a.x) / 2;
    const y0 = Math.max(a.y, b.y), y1 = Math.min(aB, bB);
    if (y1 > y0) return { x: edgeX, y: (y0 + y1) / 2, y0, y1, x0: edgeX, x1: edgeX, axis: 'v' };
  }
  // Horizontal shared edge (top-bottom)
  if (Math.abs(aB - b.y) <= tolerance || Math.abs(bB - a.y) <= tolerance) {
    const edgeY = Math.abs(aB - b.y) <= tolerance ? (aB + b.y) / 2 : (bB + a.y) / 2;
    const x0 = Math.max(a.x, b.x), x1 = Math.min(aR, bR);
    if (x1 > x0) return { x: (x0 + x1) / 2, y: edgeY, x0, x1, y0: edgeY, y1: edgeY, axis: 'h' };
  }
  // Overlapping
  const ox0 = Math.max(a.x, b.x), ox1 = Math.min(aR, bR);
  const oy0 = Math.max(a.y, b.y), oy1 = Math.min(aB, bB);
  if (ox1 > ox0 && oy1 > oy0) return { x: (ox0 + ox1) / 2, y: (oy0 + oy1) / 2, axis: 'o' };
  return null;
}

// Check if any door/passage element from the block's elements sits on the shared edge between a and b
// This represents a physical opening (doorway) in a wall
function doorOnSharedEdge(a, b, blockEls, tolerance = 20) {
  const edge = getSharedEdge(a, b);
  if (!edge) return false;

  for (const el of blockEls) {
    if (!(['door', 'window'].includes((el.type || '').toLowerCase()))) continue;
    const er = el.x + el.w, eb = el.y + el.h;

    if (edge.axis === 'v') {
      // Door must be near the edge X and overlap the shared Y range
      const doorCx = el.x + el.w / 2;
      if (Math.abs(doorCx - edge.x) <= tolerance) {
        const dy0 = Math.max(el.y, edge.y0), dy1 = Math.min(eb, edge.y1);
        if (dy1 > dy0) return true;
      }
    } else if (edge.axis === 'h') {
      const doorCy = el.y + el.h / 2;
      if (Math.abs(doorCy - edge.y) <= tolerance) {
        const dx0 = Math.max(el.x, edge.x0), dx1 = Math.min(er, edge.x1);
        if (dx1 > dx0) return true;
      }
    } else if (edge.axis === 'o') {
      // Overlapping rooms — door near the center of overlap
      if (Math.abs((el.x + el.w / 2) - edge.x) <= tolerance &&
        Math.abs((el.y + el.h / 2) - edge.y) <= tolerance) return true;
    }
  }
  return false;
}

// Check if a wall on the current floor blocks the shared boundary between two elements
function wallBlocksEdge(a, b, floorId) {
  const edge = getSharedEdge(a, b);
  if (!edge) return false;

  const floorWalls = state.walls.filter(w => w.floorId === floorId);
  if (floorWalls.length === 0) return false;

  // For a horizontal edge: check if any wall crosses most of the shared x-segment
  // For a vertical edge: check if any wall covers most of the shared y-segment
  for (const wall of floorWalls) {
    const wR = wall.x + wall.w, wB = wall.y + wall.h;

    if (edge.axis === 'v') {
      // Wall must overlap the edge x and span a significant part of the y overlap
      if (wall.x <= edge.x + 8 && wR >= edge.x - 8) {
        const wy0 = Math.max(wall.y, edge.y0), wy1 = Math.min(wB, edge.y1);
        const overlapLen = wy1 - wy0;
        const edgeLen = edge.y1 - edge.y0;
        if (overlapLen > edgeLen * 0.4) return true;
      }
    } else if (edge.axis === 'h') {
      if (wall.y <= edge.y + 8 && wB >= edge.y - 8) {
        const wx0 = Math.max(wall.x, edge.x0), wx1 = Math.min(wR, edge.x1);
        const overlapLen = wx1 - wx0;
        const edgeLen = edge.x1 - edge.x0;
        if (overlapLen > edgeLen * 0.4) return true;
      }
    } else if (edge.axis === 'o') {
      // Overlapping rooms — check if wall is inside overlap region
      if (wall.x < edge.x + 10 && wR > edge.x - 10 && wall.y < edge.y + 10 && wB > edge.y - 10) return true;
    }
  }
  return false;
}

function buildGraph() {
  // adjacency: Map<elId, [{neighborId, cost, type:'same'|'stair', meta}]>
  const adj = new Map();
  const allEls = allElements();

  allEls.forEach(r => adj.set(r.el.id, []));

  // Same-floor adjacency: two elements connect if they physically touch or overlap.
  // No passage-type requirement — any touching rooms are considered connected.
  // Drawn walls can still block edges unless a door element sits on that edge.
  state.floors.forEach(f => {
    // Get all elements on this floor across all blocks
    const floorEls = f.blocks.flatMap(b => b.elements);

    for (let i = 0; i < floorEls.length; i++) {
      for (let j = i + 1; j < floorEls.length; j++) {
        const a = floorEls[i], bEl = floorEls[j];
        if (!rectsOverlapOrTouch(a, bEl)) continue;

        // If a drawn wall blocks the shared edge, only allow through if
        // a door element is physically on that edge (door = opening in the wall).
        const blocked = wallBlocksEdge(a, bEl, f.id);
        if (blocked) {
          const hasDoorOpening = doorOnSharedEdge(a, bEl, floorEls);
          if (!hasDoorOpening) continue;
        }

        const d = dist(a, bEl);
        adj.get(a.id).push({ neighborId: bEl.id, cost: d, type: 'same', meta: { floorId: f.id, floorName: f.name } });
        adj.get(bEl.id).push({ neighborId: a.id, cost: d, type: 'same', meta: { floorId: f.id, floorName: f.name } });
      }
    }
  });

  // Vertical links: stairs, elevators, and Stair Hall junctions.
  // Same-floor hub links are cheaper; cross-floor/block transitions carry the normal stair penalty.
  const STAIR_COST = 120;
  const JUNCTION_COST = 35;
  state.stairLinks.forEach(lk => {
    if (adj.has(lk.fromElId) && adj.has(lk.toElId)) {
      const fromFloor = state.floors.find(f => f.id === lk.fromFloorId);
      const toFloor = state.floors.find(f => f.id === lk.toFloorId);
      const fromRec = getElById(lk.fromElId);
      const toRec = getElById(lk.toElId);
      const isCrossFloor = lk.fromFloorId !== lk.toFloorId;
      const usesJunction = !!(fromRec && toRec && (isVerticalJunction(fromRec.el) || isVerticalJunction(toRec.el)));
      const linkCost = isCrossFloor ? STAIR_COST : JUNCTION_COST;
      const baseMeta = { usesJunction, isCrossFloor };

      adj.get(lk.fromElId).push({
        neighborId: lk.toElId, cost: linkCost, type: 'stair',
        meta: { ...baseMeta, fromFloorName: fromFloor?.name, toFloorName: toFloor?.name }
      });
      adj.get(lk.toElId).push({
        neighborId: lk.fromElId, cost: linkCost, type: 'stair',
        meta: { ...baseMeta, fromFloorName: toFloor?.name, toFloorName: fromFloor?.name }
      });
    }
  });

  // Universal element links (cross-floor or same-floor)
  const LINK_COST = 100;
  state.universalLinks.forEach(lk => {
    if (adj.has(lk.fromElId) && adj.has(lk.toElId)) {
      const fromFloor = state.floors.find(f => f.id === lk.fromFloorId);
      const toFloor = state.floors.find(f => f.id === lk.toFloorId);
      const isCrossFloor = lk.fromFloorId !== lk.toFloorId;
      adj.get(lk.fromElId).push({
        neighborId: lk.toElId, cost: LINK_COST, type: isCrossFloor ? 'universal' : 'same',
        meta: { fromFloorName: fromFloor?.name, toFloorName: toFloor?.name, floorId: lk.toFloorId, floorName: toFloor?.name, isUniversalLink: true }
      });
      adj.get(lk.toElId).push({
        neighborId: lk.fromElId, cost: LINK_COST, type: isCrossFloor ? 'universal' : 'same',
        meta: { fromFloorName: toFloor?.name, toFloorName: fromFloor?.name, floorId: lk.fromFloorId, floorName: fromFloor?.name, isUniversalLink: true }
      });
    }
  });

  return adj;
}

function dijkstra(adj, startId, endId) {
  // Returns {path: [elId,...], cost, edges: [{from, to, type, meta}]}
  const dist2 = new Map();
  const prev = new Map();
  const edgeMeta = new Map(); // toId -> edge info
  const visited = new Set();
  const pq = []; // [{cost, id}]

  adj.forEach((_, id) => dist2.set(id, Infinity));
  dist2.set(startId, 0);
  pq.push({ cost: 0, id: startId });

  while (pq.length) {
    pq.sort((a, b) => a.cost - b.cost);
    const { cost, id } = pq.shift();
    if (visited.has(id)) continue;
    visited.add(id);
    if (id === endId) break;

    const neighbors = adj.get(id) || [];
    neighbors.forEach(({ neighborId, cost: edgeCost, type, meta }) => {
      const newCost = cost + edgeCost;
      if (newCost < dist2.get(neighborId)) {
        dist2.set(neighborId, newCost);
        prev.set(neighborId, id);
        edgeMeta.set(neighborId, { type, meta });
        pq.push({ cost: newCost, id: neighborId });
      }
    });
  }

  if (dist2.get(endId) === Infinity) return null; // No path

  // Reconstruct
  const path = [];
  const edges = [];
  let cur = endId;
  while (cur !== undefined) {
    path.unshift(cur);
    const meta = edgeMeta.get(cur);
    if (meta) edges.unshift({ to: cur, from: prev.get(cur), ...meta });
    cur = prev.get(cur);
  }
  return { path, cost: dist2.get(endId), edges };
}

window.openPathFinder = function () {
  clearPathHighlights();
  const allEls = allElements();
  const rooms = allEls.filter(r => !['door', 'window'].includes(r.el.type?.toLowerCase()) && !r.el.type?.startsWith('Corridor-') && r.el.type !== 'Corridor');

  const fromSel = document.getElementById('pfFrom');
  const toSel = document.getElementById('pfTo');
  fromSel.innerHTML = '';
  toSel.innerHTML = '';

  rooms.forEach(r => {
    const opt1 = document.createElement('option');
    opt1.value = r.el.id;
    opt1.textContent = elLabel(r);
    fromSel.appendChild(opt1);

    const opt2 = document.createElement('option');
    opt2.value = r.el.id;
    opt2.textContent = elLabel(r);
    toSel.appendChild(opt2);
  });

  // Default: pick second room as "to"
  if (toSel.options.length > 1) toSel.selectedIndex = 1;

  clearPathResult();
  document.getElementById('pathModal').classList.remove('hidden');
};

window.closePathModal = function () {
  document.getElementById('pathModal').classList.add('hidden');
};

window.clearPathResult = function () {
  document.getElementById('pathResult').innerHTML = '';
};

// Store current path state for floor switching
let _pathState = null;

window.clearPathHighlights = function () {
  _pathState = null;
  document.querySelectorAll('.element').forEach(el => {
    el.classList.remove('path-highlight', 'path-start', 'path-end');
    const badge = el.querySelector('.path-num');
    if (badge) badge.remove();
  });
  // Clear SVG arrows
  const svg = document.getElementById('pathArrowSvg');
  if (svg) svg.innerHTML = '';
  // Hide floor bar and clear button
  const bar = document.getElementById('pathFloorBar');
  if (bar) { bar.innerHTML = ''; bar.style.display = 'none'; }
  const cb = document.getElementById('pathClearBtn');
  if (cb) cb.style.display = 'none';
};

// Find the midpoint of the overlap segment between two touching rectangles
// Returns a point ON the shared wall — the actual doorway/passage location
function getSharedWallMidpoint(a, b) {
  const edge = getSharedEdge(a, b, 10);
  if (edge) return edge;

  // Fallback: midpoint between centers
  return {
    x: (a.x + a.w / 2 + b.x + b.w / 2) / 2,
    y: (a.y + a.h / 2 + b.y + b.h / 2) / 2,
    axis: 'f'
  };
}

function drawPathArrows(path, edges, activeFloorId, animateLines) {
  const svg = document.getElementById('pathArrowSvg');
  if (!svg) return;
  svg.innerHTML = '';



  const R = 14;

  // --- Collect only the elements on this floor, in path order ---
  const onFloor = path.filter(elId => {
    const rec = getElById(elId);
    return rec && rec.floorId === activeFloorId;
  });
  if (onFloor.length === 0) return;

  // --- Find the cross-floor exit: last element on this floor that has a cross-floor edge ---
  // exitElId = the element on THIS floor whose NEXT path element is on a different floor
  let stairExitElId = null;
  let nextFloorId = null;
  let exitEdgeType = null; // 'stair' or 'universal'
  for (let i = 0; i < path.length - 1; i++) {
    const fromRec = getElById(path[i]);
    const toRec = getElById(path[i + 1]);
    const edge = edges.find(e => e.to === path[i + 1]);
    if (fromRec && fromRec.floorId === activeFloorId &&
      toRec && toRec.floorId !== activeFloorId &&
      edge && (edge.type === 'stair' || edge.type === 'universal')) {
      stairExitElId = path[i];
      nextFloorId = toRec.floorId;
      exitEdgeType = edge.type;
      break;
    }
  }

  // --- Build an ORTHOGONAL polyline through the path ---
  // For each consecutive pair in onFloor, we compute gate point (shared edge midpoint).
  // The line travels: roomCenter → (axis-aligned) → gate → (axis-aligned) → next roomCenter
  // We use SVG polylines so corners are always 90°, never diagonal.

  // Collect all points as a flat orthogonal polyline.
  // Key principle: the path must stay INSIDE each element's bounding box.
  // For each step A → B:
  //   - Find the shared edge (gate) between A and B
  //   - Compute the exit point on A's boundary (clamped to A's box)
  //   - Compute the entry point on B's boundary (clamped to B's box)
  //   - Route: A_center → exit_A → (gate) → entry_B → B_center
  //     using only axis-aligned (orthogonal) segments that stay inside A then inside B
  function buildPolyline() {
    const pts = [];

    // Clamp a point to be inside a rect's boundary (on the edge if outside)
    function clampToRect(px, py, el) {
      return {
        x: Math.max(el.x, Math.min(el.x + el.w, px)),
        y: Math.max(el.y, Math.min(el.y + el.h, py))
      };
    }

    // Given element el and a gate point, find the exit point on el's boundary
    // that is closest to the gate, staying on the correct edge
    function exitPoint(el, gate) {
      const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
      if (gate.axis === 'v') {
        // Gate is on left or right wall of el
        const ex = (gate.x <= cx) ? el.x : el.x + el.w;
        const ey = Math.max(el.y, Math.min(el.y + el.h, gate.y));
        return { x: ex, y: ey };
      } else if (gate.axis === 'h') {
        // Gate is on top or bottom wall of el
        const ey = (gate.y <= cy) ? el.y : el.y + el.h;
        const ex = Math.max(el.x, Math.min(el.x + el.w, gate.x));
        return { x: ex, y: ey };
      } else {
        // Overlapping — use center
        return { x: cx, y: cy };
      }
    }

    for (let i = 0; i < onFloor.length; i++) {
      const rec = getElById(onFloor[i]);
      if (!rec) continue;
      const el = rec.el;
      const cx = el.x + el.w / 2, cy = el.y + el.h / 2;

      if (i === 0) {
        pts.push({ x: cx, y: cy, elId: onFloor[i], isGate: false });
      }

      if (i < onFloor.length - 1) {
        const nextRec = getElById(onFloor[i + 1]);
        if (!nextRec) continue;
        const nel = nextRec.el;
        const ncx = nel.x + nel.w / 2, ncy = nel.y + nel.h / 2;

        const gate = getSharedWallMidpoint(el, nel);

        if (gate.axis === 'o') {
          // Overlapping rooms — go horizontal then vertical, staying inside overlap
          pts.push({ x: ncx, y: cy, isGate: true });
        } else if (gate.axis === 'f') {
          // No shared wall — rooms are non-adjacent. Draw a clean L-shaped route
          // between centers: horizontal first, then vertical
          if (Math.abs(ncx - cx) > 1) pts.push({ x: ncx, y: cy, isGate: true });
        } else {
          // Get the exact exit from current element and entry into next element
          const exitA = exitPoint(el, gate);
          const entryB = exitPoint(nel, gate);

          // Route from current center to exitA (orthogonal, inside el)
          // We go to the exit edge first: if vertical gate, move Y first then X;
          // if horizontal gate, move X first then Y — so we stay inside el
          if (gate.axis === 'v') {
            // Exit through left or right wall — move Y first (stay in el), then X to wall
            if (Math.abs(cy - exitA.y) > 1) pts.push({ x: cx, y: exitA.y, isGate: true });
            pts.push({ x: exitA.x, y: exitA.y, isGate: true });
          } else {
            // Exit through top or bottom wall — move X first (stay in el), then Y to wall
            if (Math.abs(cx - exitA.x) > 1) pts.push({ x: exitA.x, y: cy, isGate: true });
            pts.push({ x: exitA.x, y: exitA.y, isGate: true });
          }

          // Gate crossing point
          pts.push({ x: gate.x, y: gate.y, isGate: true });

          // Route from entryB to next center (orthogonal, inside nel)
          if (gate.axis === 'v') {
            // Enter through left or right wall — move Y to match center, then X to center
            if (Math.abs(entryB.y - ncy) > 1) pts.push({ x: entryB.x, y: ncy, isGate: true });
            // (horizontal segment to ncx is implicit — entryB.x to ncx at ncy)
          } else {
            // Enter through top or bottom wall — move X to match center, then Y to center
            if (Math.abs(entryB.x - ncx) > 1) pts.push({ x: ncx, y: entryB.y, isGate: true });
            // (vertical segment to ncy is implicit — entryB.y to ncy at ncx)
          }
        }

        pts.push({ x: ncx, y: ncy, elId: onFloor[i + 1], isGate: false });
      }
    }

    // Deduplicate adjacent near-identical points
    const out = [pts[0]];
    for (let i = 1; i < pts.length; i++) {
      const p = pts[i], prev = out[out.length - 1];
      if (Math.abs(p.x - prev.x) > 0.5 || Math.abs(p.y - prev.y) > 0.5) out.push(p);
    }
    return out;
  }

  const polyPts = buildPolyline();

  // Split polyline into segments: each segment is from one node to next, passing through gates
  // We need per-segment info for: arrowhead at node, stairSeg coloring, animation
  const segments = [];
  let segStart = 0;
  for (let i = 1; i < polyPts.length; i++) {
    if (!polyPts[i].isGate) {
      // This is a node point — build a segment from segStart..i
      const segPts = polyPts.slice(segStart, i + 1);
      const srcElId = polyPts[segStart].elId;
      const destElId = polyPts[i].elId;
      const isStairSeg = !!(destElId && destElId === stairExitElId && exitEdgeType === 'stair');
      const isUniversalSeg = !!(destElId && destElId === stairExitElId && exitEdgeType === 'universal');

      // Only offset at the very first and very last node of the entire path
      // (where start/end marker circles actually exist).
      // Intermediate nodes have no circles → no offset → no gap.
      const srcIsGlobalFirst = (srcElId === path[0]);
      const destIsGlobalLast = (destElId === path[path.length - 1]);

      // Build sub-segments within this segment
      const subSegs = [];
      for (let k = 0; k < segPts.length - 1; k++) {
        let x1 = segPts[k].x, y1 = segPts[k].y;
        let x2 = segPts[k + 1].x, y2 = segPts[k + 1].y;
        const dx = x2 - x1, dy = y2 - y1;
        const len = Math.sqrt(dx * dx + dy * dy) || 1;
        const ux = dx / len, uy = dy / len;
        // Only offset from source circle if this is the first sub-segment AND src is the global start
        if (k === 0 && !segPts[k].isGate && srcIsGlobalFirst) { x1 += ux * R; y1 += uy * R; }
        // Only offset into destination circle if this is the last sub-segment AND dest is the global end
        const isLast = k === segPts.length - 2;
        if (isLast && !segPts[k + 1].isGate && destIsGlobalLast) { x2 -= ux * (R + 2); y2 -= uy * (R + 2); }
        const segLen = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
        if (segLen > 0.5) subSegs.push({ x1, y1, x2, y2, segLen });
      }

      segments.push({
        subSegs, destElId, isStairSeg, isUniversalSeg,
        totalLen: subSegs.reduce((s, ss) => s + ss.segLen, 0)
      });
      segStart = i;
    }
  }

  // --- Draw only start/end markers (no numbered mid-node circles) ---
  const nodeGs = []; // { g, elId, pathIdx }
  onFloor.forEach(elId => {
    const rec = getElById(elId);
    if (!rec) return;
    const pathIdx = path.indexOf(elId);
    const isFirst = (pathIdx === 0);
    const isLast = (pathIdx === path.length - 1);
    // Skip intermediate nodes — no circles, no numbers
    if (!isFirst && !isLast) {
      nodeGs.push({ g: null, elId, pathIdx });
      return;
    }
    const cx = rec.el.x + rec.el.w / 2, cy = rec.el.y + rec.el.h / 2;
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    if (animateLines) g.style.opacity = '0';
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', cx); circle.setAttribute('cy', cy); circle.setAttribute('r', R);
    circle.className.baseVal = 'path-node-circle ' + (isFirst ? 'start-circle' : 'end-circle');
    g.appendChild(circle);
    if (isFirst) {
      // Person/human icon
      const iconG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      iconG.setAttribute('transform', `translate(${cx - 7}, ${cy - 9}) scale(0.875)`);
      iconG.setAttribute('fill', '#27ae60');
      const head = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      head.setAttribute('cx', '8'); head.setAttribute('cy', '4'); head.setAttribute('r', '3.5');
      iconG.appendChild(head);
      const body = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      body.setAttribute('d', 'M3,20 C3,13 13,13 13,20');
      iconG.appendChild(body);
      g.appendChild(iconG);
    } else {
      // Pin/destination icon
      const iconG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      iconG.setAttribute('transform', `translate(${cx - 6}, ${cy - 10}) scale(0.75)`);
      iconG.setAttribute('fill', '#e74c3c');
      const pin = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      pin.setAttribute('d', 'M8,0 C4.7,0 2,2.7 2,6 C2,10.5 8,16 8,16 C8,16 14,10.5 14,6 C14,2.7 11.3,0 8,0 Z');
      iconG.appendChild(pin);
      const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      dot.setAttribute('cx', '8'); dot.setAttribute('cy', '6'); dot.setAttribute('r', '2.2');
      dot.setAttribute('fill', '#fff');
      iconG.appendChild(dot);
      g.appendChild(iconG);
    }
    svg.appendChild(g);
    nodeGs.push({ g, elId, pathIdx });
  });

  // --- Stair exit label (shown when animation reaches stair node) ---
  let stairLabelEl = null;
  if (stairExitElId) {
    const exitRec = getElById(stairExitElId);
    const toFloor = state.floors.find(f => f.id === nextFloorId);
    if (exitRec) {
      const cx = exitRec.el.x + exitRec.el.w / 2;
      const cy = exitRec.el.y + exitRec.el.h / 2;
      const lbl = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      lbl.setAttribute('x', cx); lbl.setAttribute('y', cy + 28);
      lbl.className.baseVal = 'path-floor-badge';
      const exitIcon = exitEdgeType === 'universal' ? '\ud83d\udd17' : '\ud83e\ude9c';
      lbl.textContent = exitIcon + ' \u2192 ' + (toFloor?.name || 'Next Floor');
      if (animateLines) lbl.style.opacity = '0';
      svg.appendChild(lbl);
      stairLabelEl = lbl;
    }
  }

  // --- Static draw (floor-bar manual switch) ---
  if (!animateLines) {
    segments.forEach(({ subSegs, isStairSeg, isUniversalSeg, destElId }) => {
      subSegs.forEach((ss, idx) => {
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', ss.x1); line.setAttribute('y1', ss.y1);
        line.setAttribute('x2', ss.x2); line.setAttribute('y2', ss.y2);
        const lineClass = isStairSeg ? ' stair-line' : isUniversalSeg ? ' universal-line' : '';
        line.className.baseVal = 'path-arrow-line' + lineClass;

        svg.appendChild(line);
      });
    });
    nodeGs.forEach(({ g }) => { if (g) g.style.opacity = '1'; });
    if (stairLabelEl) stairLabelEl.style.opacity = '1';
    return;
  }

  // --- Animated draw ---
  // Show the start node immediately
  const firstNodeG = nodeGs.find(n => n.elId === onFloor[0]);
  if (firstNodeG && firstNodeG.g) firstNodeG.g.style.opacity = '1';

  const SPEED_PX_PER_MS = 0.35;
  let segIdx = 0;

  function animateSegment() {
    if (segIdx >= segments.length) {
      nodeGs.forEach(({ g }) => { if (g) g.style.opacity = '1'; });
      if (stairLabelEl) stairLabelEl.style.opacity = '1';
      return;
    }

    const seg = segments[segIdx];
    let subIdx = 0;

    function animateSubSeg() {
      if (subIdx >= seg.subSegs.length) {
        // All sub-segments drawn — reveal destination node
        if (seg.destElId) {
          const nodeG = nodeGs.find(n => n.elId === seg.destElId);
          if (nodeG && nodeG.g) nodeG.g.style.opacity = '1';
        }
        segIdx++;

        // If we just finished drawing INTO the cross-floor exit node → trigger floor switch
        if ((seg.isStairSeg || seg.isUniversalSeg) && nextFloorId !== null) {
          if (stairLabelEl) stairLabelEl.style.opacity = '1';
          setTimeout(() => {
            const nextFloor = state.floors.find(f => f.id === nextFloorId);
            const canvasEl = document.getElementById('canvas');
            canvasEl.style.transition = 'opacity 0.3s';
            canvasEl.style.opacity = '0';
            setTimeout(() => {
              state.currFloorId = nextFloorId;
              state.currBlockId = nextFloor?.blocks[0]?.id || state.currBlockId;
              state.selectedId = null;
              renderAll();
              setTimeout(() => {
                canvasEl.style.opacity = '1';
                drawPathArrows(_pathState.path, _pathState.edges, nextFloorId, true);
                applyPathHighlights(_pathState.path, nextFloorId);
                buildFloorBar(_pathState.path, _pathState.edges, nextFloorId);
              }, 60);
            }, 300);
          }, 600);
          return;
        }

        animateSegment();
        return;
      }

      const ss = seg.subSegs[subIdx];
      const duration = ss.segLen / SPEED_PX_PER_MS;

      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', ss.x1); line.setAttribute('y1', ss.y1);
      line.setAttribute('x2', ss.x2); line.setAttribute('y2', ss.y2);
      const lineClass = seg.isStairSeg ? ' stair-line' : seg.isUniversalSeg ? ' universal-line' : '';
      line.className.baseVal = 'path-arrow-line' + lineClass;
      line.style.strokeDasharray = `${ss.segLen} ${ss.segLen}`;
      line.style.strokeDashoffset = `${ss.segLen}`;
      line.style.animation = 'none';
      svg.appendChild(line);

      const start = performance.now();
      function step(now) {
        const progress = Math.min((now - start) / duration, 1);
        line.style.strokeDashoffset = ss.segLen * (1 - progress);
        if (progress < 1) { requestAnimationFrame(step); return; }

        // Sub-segment fully drawn — restore flowing dash animation
        line.style.strokeDasharray = '';
        line.style.strokeDashoffset = '';
        line.style.animation = '';

        subIdx++;
        animateSubSeg();
      }
      requestAnimationFrame(step);
    }

    animateSubSeg();
  }

  animateSegment();
}

function buildFloorBar(path, edges, activeFloorId) {
  const bar = document.getElementById('pathFloorBar');
  if (!bar) return;
  // Get unique floors in path order
  const floorsSeen = [];
  const floorSet = new Set();
  path.forEach(elId => {
    const rec = getElById(elId);
    if (rec && !floorSet.has(rec.floorId)) {
      floorSet.add(rec.floorId);
      const floor = state.floors.find(f => f.id === rec.floorId);
      floorsSeen.push({ id: rec.floorId, name: floor?.name || 'Floor' });
    }
  });

  if (floorsSeen.length <= 1) { bar.style.display = 'none'; return; }

  bar.innerHTML = '<span style="display:flex;align-items:center;gap:6px;color:var(--text-secondary);font-weight:600;"><i data-lucide="map" style="width:14px;height:14px;color:var(--accent-primary);"></i> Floor:</span>';
  floorsSeen.forEach(f => {
    const btn = document.createElement('button');
    btn.textContent = f.name;
    if (f.id === activeFloorId) btn.classList.add('active');
    btn.onclick = () => {
      if (!_pathState) return;
      const floor = state.floors.find(fl => fl.id === f.id);
      state.currFloorId = f.id;
      state.currBlockId = floor?.blocks[0]?.id || state.currBlockId;
      state.selectedId = null;
      renderAll();
      setTimeout(() => {
        drawPathArrows(_pathState.path, _pathState.edges, f.id, false);
        applyPathHighlights(_pathState.path, f.id);
        buildFloorBar(_pathState.path, _pathState.edges, f.id);
      }, 60);
    };
    bar.appendChild(btn);
  });
  bar.style.display = 'flex';
  if (window.lucide) window.lucide.createIcons();
}

function applyPathHighlights(path, floorId) {
  document.querySelectorAll('.element').forEach(el => {
    el.classList.remove('path-highlight', 'path-start', 'path-end');
    const badge = el.querySelector('.path-num');
    if (badge) badge.remove();
  });
  path.forEach((elId, idx) => {
    const rec = getElById(elId);
    if (!rec || rec.floorId !== floorId) return;
    const domEl = document.getElementById('el-' + elId);
    if (!domEl) return;
    if (idx === 0) domEl.classList.add('path-start');
    else if (idx === path.length - 1) domEl.classList.add('path-end');
    else domEl.classList.add('path-highlight');
  });
}

window.runPathFinder = function () {
  clearPathHighlights();
  const fromId = parseInt(document.getElementById('pfFrom').value);
  const toId = parseInt(document.getElementById('pfTo').value);

  if (fromId === toId) {
    document.getElementById('pathResult').innerHTML = '<div class="path-empty">Start and end are the same room!</div>';
    return;
  }

  const adj = buildGraph();
  const result = dijkstra(adj, fromId, toId);
  const resultDiv = document.getElementById('pathResult');

  if (!result) {
    const fromRec = getElById(fromId);
    const toRec = getElById(toId);
    const sameFloor = fromRec && toRec && fromRec.floorId === toRec.floorId;

    let reason = '';
    let fix = '';

    if (!sameFloor) {
      // Cross-floor: check if either floor has any stair/universal links
      const fromFloorHasLinks = state.stairLinks.some(lk => lk.fromFloorId === fromRec?.floorId || lk.toFloorId === fromRec?.floorId)
        || state.universalLinks.some(lk => lk.fromFloorId === fromRec?.floorId || lk.toFloorId === fromRec?.floorId);
      const toFloorHasLinks = state.stairLinks.some(lk => lk.fromFloorId === toRec?.floorId || lk.toFloorId === toRec?.floorId)
        || state.universalLinks.some(lk => lk.fromFloorId === toRec?.floorId || lk.toFloorId === toRec?.floorId);
      const totalLinks = state.stairLinks.length + state.universalLinks.length;

      if (totalLinks === 0) {
        reason = 'No connections exist between any floors.';
        fix = 'Select any element on the canvas → click <b>🔗 Link to Any Element</b> in the Properties panel to connect elements across floors. You can also use Staircase, Elevator, or Stair Hall linking.';
      } else if (!fromFloorHasLinks) {
        reason = `<b>${fromRec?.floorName}</b> has no cross-floor links.`;
        fix = `Go to <b>${fromRec?.floorName}</b>, select any element → click <b>🔗 Link to Any Element</b> to connect it to an element on another floor.`;
      } else if (!toFloorHasLinks) {
        reason = `<b>${toRec?.floorName}</b> has no cross-floor links.`;
        fix = `Go to <b>${toRec?.floorName}</b>, select any element → click <b>🔗 Link to Any Element</b> to connect it to an element on another floor.`;
      } else {
        reason = 'The linked elements on each floor are not connected to the rooms in the path.';
        fix = 'Make sure the linked elements are touching (overlapping) corridors or rooms on their floor, forming a connected chain.';
      }
    } else {
      reason = 'The rooms are on the same floor but no connected path exists between them.';
      fix = 'Paths travel through <b>Corridors</b>, <b>Doors</b>, <b>Elevators</b>, <b>Staircases</b>, <b>Stair Halls</b>, and <b>Element Links</b>. Make sure each room touches a Corridor or has a Door element on its shared wall, or use <b>🔗 Link to Any Element</b> to directly connect them.';
    }

    resultDiv.innerHTML = `<div style="background:#fff5f5;border:1px solid #fca5a5;border-radius:8px;padding:12px;font-size:13px;line-height:1.6;">
      <div style="font-weight:700;color:#dc2626;margin-bottom:6px;">❌ No path found</div>
      <div style="color:#7f1d1d;margin-bottom:8px;">${reason}</div>
      <div style="background:#fef2f2;border-radius:6px;padding:8px;color:#991b1b;">
        <b>How to fix:</b><br>${fix}
      </div>
    </div>`;
    return;
  }

  const { path, edges } = result;
  const numFloors = new Set(path.map(id => getElById(id)?.floorId)).size;

  // Show compact summary in modal
  resultDiv.innerHTML = `<div class="path-summary" style="margin-bottom:8px;">
    ✅ Path found — <strong>${path.length} spaces</strong> across <strong>${numFloors} floor(s)</strong>
    ${numFloors > 1 ? '<br><span style="font-size:12px;color:#8e44ad;">Use the floor switcher on the map to see each floor.</span>' : ''}
  </div>`;

  // Save path state
  _pathState = { path, edges };

  // Switch canvas to start floor
  const startRec = getElById(fromId);
  if (startRec) {
    state.currFloorId = startRec.floorId;
    state.currBlockId = startRec.blockId;
    state.selectedId = null;
    renderAll();
  }

  // Close modal and draw arrows on canvas
  document.getElementById('pathModal').classList.add('hidden');

  setTimeout(() => {
    const activeFloor = startRec ? startRec.floorId : state.currFloorId;
    drawPathArrows(path, edges, activeFloor, true);
    applyPathHighlights(path, activeFloor);
    buildFloorBar(path, edges, activeFloor);
    const cb = document.getElementById('pathClearBtn');
    if (cb) cb.style.display = 'block';
    showToast(`Path found: ${path.length} steps — animating on map`);
  }, 60);
};
